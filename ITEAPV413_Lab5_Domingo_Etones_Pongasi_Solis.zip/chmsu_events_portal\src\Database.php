<?php
/**
 * Data-tier gateway: the only place a PDO connection is created.
 */
declare(strict_types=1);

final class Database
{
    private static ?PDO $pdo = null;

    /**
     * Returns the shared connection.
     *  - ERRMODE_EXCEPTION   : errors are thrown, never silently ignored
     *  - EMULATE_PREPARES off: real server-side prepared statements, so
     *    user values are sent separately from the SQL text (no SQLi)
     */
    public static function connection(): PDO
    {
        if (self::$pdo === null) {
            $c = App::config('db');
            $dsn = "mysql:host={$c['host']};port={$c['port']};dbname={$c['name']};charset={$c['charset']}";
            self::$pdo = new PDO($dsn, $c['user'], $c['pass'], [
                PDO::ATTR_ERRMODE            => PDO::ERRMODE_EXCEPTION,
                PDO::ATTR_DEFAULT_FETCH_MODE => PDO::FETCH_ASSOC,
                PDO::ATTR_EMULATE_PREPARES   => false,
            ]);
            // Store and compare times in Philippine Standard Time (UTC+8).
            self::$pdo->exec("SET time_zone = '+08:00'");
        }
        return self::$pdo;
    }

    /** Prepares and executes a statement with bound parameters. */
    public static function run(string $sql, array $params = []): PDOStatement
    {
        $stmt = self::connection()->prepare($sql);
        $stmt->execute($params);
        return $stmt;
    }
}

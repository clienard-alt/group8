/**
 * Live dashboard (Fetch API).
 * Requests api/dashboard.php every 5 seconds and patches the DOM in place.
 * Server text is always inserted with textContent, never innerHTML, so a
 * value such as "<script>" is displayed as text and never executed.
 */
(function () {
  'use strict';

  const REFRESH_MS = 5000;
  const liveText = document.getElementById('liveText');
  const livePill = document.getElementById('liveStatus');
  const eventBars = document.getElementById('eventBars');
  const collegeBars = document.getElementById('collegeBars');
  const feed = document.getElementById('activityFeed');
  let timer = null;

  /** Small helper: create an element with a class and text. */
  function el(tag, className, text) {
    const node = document.createElement(tag);
    if (className) node.className = className;
    if (text !== undefined && text !== null) node.textContent = String(text);
    return node;
  }

  function fmtTime(hms) {
    const [h, m] = hms.split(':').map(Number);
    const ampm = h >= 12 ? 'PM' : 'AM';
    return ((h % 12) || 12) + ':' + String(m).padStart(2, '0') + ' ' + ampm;
  }

  function fmtDate(ymd) {
    const d = new Date(ymd + 'T00:00:00');
    return d.toLocaleDateString('en-PH', { month: 'short', day: 'numeric', year: 'numeric' });
  }

  function setStat(key, value) {
    const node = document.querySelector('[data-stat="' + key + '"]');
    if (!node) return;
    const text = String(value);
    if (node.textContent !== text) {
      node.textContent = text;
      node.classList.remove('bump');
      void node.offsetWidth; // restart the CSS animation
      node.classList.add('bump');
    }
  }

  function renderEvents(events) {
    const items = events.map(function (ev) {
      const li = el('li', 'event-bar');
      const top = el('div', 'eb-top');
      const name = el('div', 'eb-name');
      name.appendChild(el('span', 'org-tag', ev.acronym));
      name.appendChild(el('span', 'eb-title', ev.title));
      top.appendChild(name);
      top.appendChild(el('span', 'badge status-' + ev.status.toLowerCase(), ev.status));
      li.appendChild(top);

      li.appendChild(el('div', 'eb-meta',
        fmtDate(ev.event_date) + ' · ' + fmtTime(ev.start_time) + '–' + fmtTime(ev.end_time) + ' · ' + ev.venue));

      const pct = Math.min(100, Math.round((ev.attendees / ev.capacity) * 100));
      const bar = el('div', 'progress');
      bar.setAttribute('role', 'progressbar');
      bar.setAttribute('aria-label', ev.title + ' attendance');
      bar.setAttribute('aria-valuenow', String(pct));
      bar.setAttribute('aria-valuemin', '0');
      bar.setAttribute('aria-valuemax', '100');
      const fill = el('div', 'progress-bar');
      fill.style.width = pct + '%'; // CSSOM, allowed by the CSP
      bar.appendChild(fill);
      li.appendChild(bar);

      const nums = el('div', 'eb-nums');
      nums.appendChild(el('span', '', ev.attendees + ' / ' + ev.capacity + ' attended (' + pct + '%)'));
      if (ev.status === 'Ongoing' || ev.inside > 0) {
        nums.appendChild(el('span', 'inside', ev.inside + ' inside now'));
      }
      li.appendChild(nums);
      return li;
    });
    if (items.length === 0) items.push(el('li', 'text-secondary p-3', 'No events yet.'));
    eventBars.replaceChildren.apply(eventBars, items);
  }

  function renderColleges(rows) {
    const max = Math.max(1, ...rows.map(function (r) { return r.total; }));
    collegeBars.replaceChildren.apply(collegeBars, rows.map(function (r) {
      const li = el('li', 'cb-row');
      li.appendChild(el('span', 'cb-code', r.code));
      const track = el('span', 'cb-track');
      const fill = el('span', 'cb-fill');
      fill.style.width = Math.round((r.total / max) * 100) + '%';
      track.appendChild(fill);
      li.appendChild(track);
      li.appendChild(el('span', 'cb-num', r.total));
      return li;
    }));
  }

  function renderFeed(rows) {
    const items = rows.map(function (r) {
      const li = el('li', 'feed-item ' + (r.kind === 'in' ? 'is-in' : 'is-out'));
      li.appendChild(el('span', 'feed-dot'));
      const body = el('div');
      const line = el('div');
      line.appendChild(el('strong', '', r.first_name + ' ' + r.last_name));
      line.appendChild(document.createTextNode(r.kind === 'in' ? ' timed in to ' : ' timed out of '));
      line.appendChild(el('span', '', r.title));
      body.appendChild(line);
      const at = new Date(r.happened_at.replace(' ', 'T'));
      body.appendChild(el('div', 'feed-time',
        r.course + ' · ' + at.toLocaleDateString('en-PH', { month: 'short', day: 'numeric' }) + ', ' +
        at.toLocaleTimeString('en-PH', { hour: 'numeric', minute: '2-digit' })));
      li.appendChild(body);
      return li;
    });
    if (items.length === 0) items.push(el('li', 'text-secondary', 'No activity yet.'));
    feed.replaceChildren.apply(feed, items);
  }

  async function refresh() {
    try {
      const res = await fetch('api/dashboard.php', {
        headers: { Accept: 'application/json' },
        credentials: 'same-origin',
        cache: 'no-store',
      });
      if (res.status === 401) {
        window.location.href = 'login.php';
        return;
      }
      const data = await res.json();
      if (!res.ok || !data.ok) throw new Error(data.message || 'HTTP ' + res.status);

      Object.keys(data.totals).forEach(function (k) { setStat(k, data.totals[k]); });
      renderEvents(data.events);
      renderColleges(data.by_college);
      renderFeed(data.activity);
      livePill.classList.remove('is-error');
      liveText.textContent = 'Live · updated ' + data.generated_at;
    } catch (err) {
      livePill.classList.add('is-error');
      liveText.textContent = 'Offline · retrying';
      console.warn('Dashboard refresh failed:', err.message);
    }
  }

  function start() {
    stop();
    refresh();
    timer = setInterval(refresh, REFRESH_MS);
  }

  function stop() {
    if (timer) clearInterval(timer);
    timer = null;
  }

  // Save requests while the tab is hidden; refresh immediately on return.
  document.addEventListener('visibilitychange', function () {
    if (document.hidden) stop(); else start();
  });

  start();
})();

<?php
/**
 * Officer login. Officers manage events and view attendance records;
 * students only use the public attendance kiosk.
 */
declare(strict_types=1);
require __DIR__ . '/src/bootstrap.php';

if (Auth::check()) {
    App::redirect('index.php');
}

// Only allow redirects to local page names (prevents open redirects).
$next = basename((string) ($_GET['next'] ?? $_POST['next'] ?? 'index.php'));
if (!preg_match('/^[a-z_]+\.php$/', $next) || $next === 'login.php') {
    $next = 'index.php';
}

$error = '';
$username = '';
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $username = trim((string) ($_POST['username'] ?? ''));
    if (!App::checkCsrf()) {
        $error = 'Your session expired. Please try again.';
    } elseif (($wait = Auth::lockedOutFor()) > 0) {
        $error = "Too many failed attempts. Try again in {$wait} seconds.";
    } elseif (Auth::attempt($username, (string) ($_POST['password'] ?? ''))) {
        App::flash('success', 'Welcome back, ' . Auth::user()['full_name'] . '.');
        App::redirect($next);
    } else {
        $error = Auth::lockedOutFor() > 0
            ? 'Too many failed attempts. Login is locked for ' . Auth::lockedOutFor() . ' seconds.'
            : 'Incorrect username or password.';
    }
}

$title = 'Officer Login';
$nav = 'login';
require __DIR__ . '/templates/layout_top.php';
?>
<div class="row justify-content-center">
  <div class="col-sm-10 col-md-7 col-xl-5">
    <div class="panel p-4 p-md-5 mt-md-4">
      <h1 class="h3 mb-1">Officer Login</h1>
      <p class="text-secondary mb-4">Sign in to manage events and attendance records.</p>
      <?php if ($error): ?>
        <div class="alert alert-danger" role="alert"><?= e($error) ?></div>
      <?php endif; ?>
      <form method="post" novalidate>
        <?= App::csrfField() ?>
        <input type="hidden" name="next" value="<?= e($next) ?>">
        <div class="mb-3">
          <label class="form-label" for="username">Username</label>
          <input class="form-control" id="username" name="username" autocomplete="username" required maxlength="40" value="<?= e($username) ?>">
        </div>
        <div class="mb-4">
          <label class="form-label" for="password">Password</label>
          <input class="form-control" id="password" name="password" type="password" autocomplete="current-password" required>
        </div>
        <button class="btn btn-gold w-100" type="submit">Sign in</button>
      </form>
      <p class="small text-secondary mt-4 mb-0">Students: use the <a href="checkin.php">Attendance Kiosk</a> to time in and out. No account is needed.</p>
    </div>
  </div>
</div>
<?php require __DIR__ . '/templates/layout_bottom.php'; ?>

<?php
/**
 * Business-logic tier: event registration (Create, Read, Update, Delete).
 * Every query uses prepare()/execute() through Database::run().
 */
declare(strict_types=1);

final class EventRepository
{
    /** SQL expression that labels an event Upcoming / Ongoing / Completed. */
    public const STATUS_SQL = "CASE
            WHEN e.event_date < CURDATE()
              OR (e.event_date = CURDATE() AND e.end_time < CURTIME()) THEN 'Completed'
            WHEN e.event_date = CURDATE() AND CURTIME() >= e.start_time THEN 'Ongoing'
            ELSE 'Upcoming' END";

    public static function all(string $search = ''): array
    {
        $sql = 'SELECT e.*, o.acronym, ' . self::STATUS_SQL . ' AS status,
                       (SELECT COUNT(*) FROM attendance_logs a WHERE a.event_id = e.event_id) AS attendees
                  FROM events e JOIN organizations o ON o.org_id = e.org_id';
        $params = [];
        if ($search !== '') {
            $sql .= ' WHERE e.title LIKE ? OR e.venue LIKE ? OR o.acronym LIKE ?';
            $like = '%' . $search . '%';
            $params = [$like, $like, $like];
        }
        $sql .= ' ORDER BY e.event_date DESC, e.start_time DESC';
        return Database::run($sql, $params)->fetchAll();
    }

    public static function find(int $id): ?array
    {
        $row = Database::run(
            'SELECT e.*, o.acronym, o.name AS org_name, ' . self::STATUS_SQL . ' AS status
               FROM events e JOIN organizations o ON o.org_id = e.org_id
              WHERE e.event_id = ?',
            [$id]
        )->fetch();
        return $row ?: null;
    }

    /** Events that accept time-in / time-out right now (held today). */
    public static function openToday(): array
    {
        return Database::run(
            'SELECT e.event_id, e.title, e.venue, e.start_time, e.end_time, o.acronym
               FROM events e JOIN organizations o ON o.org_id = e.org_id
              WHERE e.event_date = CURDATE()
              ORDER BY e.start_time'
        )->fetchAll();
    }

    public static function organizations(): array
    {
        return Database::run('SELECT org_id, acronym, name FROM organizations ORDER BY acronym')->fetchAll();
    }

    /**
     * Validates form input. Returns [cleanData, errors].
     */
    public static function validate(array $in): array
    {
        $d = [
            'org_id'      => (int) ($in['org_id'] ?? 0),
            'title'       => trim((string) ($in['title'] ?? '')),
            'description' => trim((string) ($in['description'] ?? '')),
            'venue'       => trim((string) ($in['venue'] ?? '')),
            'event_date'  => trim((string) ($in['event_date'] ?? '')),
            'start_time'  => trim((string) ($in['start_time'] ?? '')),
            'end_time'    => trim((string) ($in['end_time'] ?? '')),
            'capacity'    => (int) ($in['capacity'] ?? 0),
        ];
        $err = [];

        $orgExists = Database::run('SELECT 1 FROM organizations WHERE org_id = ?', [$d['org_id']])->fetchColumn();
        if (!$orgExists)                                   $err['org_id'] = 'Choose the hosting organization.';
        if (mb_strlen($d['title']) < 5 || mb_strlen($d['title']) > 150)
                                                           $err['title'] = 'Title must be 5 to 150 characters.';
        if (mb_strlen($d['venue']) < 3 || mb_strlen($d['venue']) > 120)
                                                           $err['venue'] = 'Venue must be 3 to 120 characters.';
        if (mb_strlen($d['description']) > 1000)           $err['description'] = 'Description is limited to 1000 characters.';
        $date = DateTime::createFromFormat('!Y-m-d', $d['event_date']);
        if (!$date || $date->format('Y-m-d') !== $d['event_date'])
                                                           $err['event_date'] = 'Enter a valid date.';
        if (!preg_match('/^\d{2}:\d{2}(:\d{2})?$/', $d['start_time'])) $err['start_time'] = 'Enter a start time.';
        if (!preg_match('/^\d{2}:\d{2}(:\d{2})?$/', $d['end_time']))   $err['end_time'] = 'Enter an end time.';
        if (!isset($err['start_time'], $err['end_time']) && $d['end_time'] <= $d['start_time'])
                                                           $err['end_time'] = 'End time must be later than the start time.';
        if ($d['capacity'] < 1 || $d['capacity'] > 5000)   $err['capacity'] = 'Capacity must be between 1 and 5000.';

        return [$d, $err];
    }

    public static function create(array $d, int $officerId): int
    {
        Database::run(
            'INSERT INTO events (org_id, title, description, venue, event_date, start_time, end_time, capacity, created_by)
             VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?)',
            [$d['org_id'], $d['title'], $d['description'] ?: null, $d['venue'], $d['event_date'],
             $d['start_time'], $d['end_time'], $d['capacity'], $officerId]
        );
        return (int) Database::connection()->lastInsertId();
    }

    public static function update(int $id, array $d): void
    {
        Database::run(
            'UPDATE events SET org_id = ?, title = ?, description = ?, venue = ?, event_date = ?,
                    start_time = ?, end_time = ?, capacity = ?
              WHERE event_id = ?',
            [$d['org_id'], $d['title'], $d['description'] ?: null, $d['venue'], $d['event_date'],
             $d['start_time'], $d['end_time'], $d['capacity'], $id]
        );
    }

    /** Deletes an event; its attendance rows are removed by ON DELETE CASCADE. */
    public static function delete(int $id): bool
    {
        return Database::run('DELETE FROM events WHERE event_id = ?', [$id])->rowCount() === 1;
    }
}

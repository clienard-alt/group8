<?php
/**
 * GET api/dashboard.php  ->  JSON data for the live dashboard.
 * Officers only (401 for guests).
 */
declare(strict_types=1);
require __DIR__ . '/../src/bootstrap.php';

if ($_SERVER['REQUEST_METHOD'] !== 'GET') {
    App::json(['ok' => false, 'message' => 'Method not allowed.'], 405);
}
Auth::requireLoginJson();

try {
    App::json(AttendanceService::dashboard());
} catch (Throwable $ex) {
    error_log('[dashboard] ' . $ex->getMessage());
    App::json(['ok' => false, 'message' => 'Dashboard data is unavailable.'], 500);
}

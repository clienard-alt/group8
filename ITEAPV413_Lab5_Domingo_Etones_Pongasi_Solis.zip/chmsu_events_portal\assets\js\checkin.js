/**
 * Attendance kiosk behaviour.
 *  - toggles between Time In and Time Out fields
 *  - limits the Course list to the chosen college
 *  - submits with the Fetch API (no page reload) and shows the result
 */
(function () {
  'use strict';

  const form = document.getElementById('attendanceForm');
  if (!form) return;

  const alertBox = document.getElementById('formAlert');
  const submitBtn = document.getElementById('submitBtn');
  const timeInOnly = document.getElementById('timeInOnly');
  const college = document.getElementById('college_id');
  const course = document.getElementById('course');
  const clock = document.getElementById('kioskClock');
  const csrf = document.querySelector('meta[name="csrf-token"]').getAttribute('content');

  const action = () => form.querySelector('input[name="action"]:checked').value;

  function applyMode() {
    const isIn = action() === 'in';
    timeInOnly.hidden = !isIn;
    submitBtn.querySelector('.label').textContent = isIn ? 'Record Time In' : 'Record Time Out';
    submitBtn.classList.toggle('btn-gold', isIn);
    submitBtn.classList.toggle('btn-navy', !isIn);
  }

  function filterCourses() {
    const opt = college.options[college.selectedIndex];
    const code = opt ? opt.dataset.code : '';
    course.querySelectorAll('optgroup').forEach(function (g) {
      const show = !code || g.dataset.college === code;
      g.hidden = !show;
      g.disabled = !show;
    });
    const sel = course.options[course.selectedIndex];
    if (sel && sel.parentElement.tagName === 'OPTGROUP' && sel.parentElement.disabled) course.value = '';
  }

  function clearErrors() {
    form.querySelectorAll('.is-invalid').forEach(function (n) { n.classList.remove('is-invalid'); });
    form.querySelectorAll('.invalid-feedback').forEach(function (n) { n.textContent = ''; });
  }

  function showErrors(errors) {
    Object.keys(errors || {}).forEach(function (field) {
      const input = document.getElementById(field);
      const msg = form.querySelector('.invalid-feedback[data-for="' + field + '"]');
      if (input) input.classList.add('is-invalid');
      if (msg) msg.textContent = errors[field];
    });
  }

  function showAlert(kind, message) {
    alertBox.className = 'alert alert-' + kind;
    alertBox.textContent = message; // textContent: server text is never parsed as HTML
    alertBox.focus();
  }

  form.addEventListener('submit', async function (e) {
    e.preventDefault();
    clearErrors();
    submitBtn.disabled = true;

    const body = new FormData(form);
    if (action() === 'in' && !document.getElementById('consent').checked) {
      body.delete('consent');
    }

    try {
      const res = await fetch('api/attendance.php', {
        method: 'POST',
        body: body,
        headers: { 'X-CSRF-Token': csrf, Accept: 'application/json' },
        credentials: 'same-origin',
      });
      const data = await res.json();

      if (data.ok) {
        showAlert('success', data.message + ' (' + data.time + ')');
        const keepEvent = form.event_id.value;
        const keepAction = action();
        form.reset();
        form.event_id.value = keepEvent;
        document.getElementById(keepAction === 'in' ? 'actIn' : 'actOut').checked = true;
        applyMode();
        filterCourses();
      } else {
        showAlert(data.code === 'duplicate' ? 'warning' : 'danger', data.message);
        showErrors(data.errors);
      }
    } catch (err) {
      showAlert('danger', 'Network error. Please check your connection and try again.');
    } finally {
      submitBtn.disabled = false;
    }
  });

  form.querySelectorAll('input[name="action"]').forEach(function (r) {
    r.addEventListener('change', function () { clearErrors(); applyMode(); });
  });
  college.addEventListener('change', filterCourses);

  function tick() {
    clock.textContent = new Date().toLocaleTimeString('en-PH', { hour: 'numeric', minute: '2-digit' });
  }
  setInterval(tick, 15000);

  applyMode();
  filterCourses();
})();

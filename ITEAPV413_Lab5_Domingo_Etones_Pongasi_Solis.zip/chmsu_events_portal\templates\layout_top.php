<?php
/**
 * Presentation tier: page shell with a sidebar (desktop) that becomes an
 * off-canvas drawer on phones. Expects $title and $nav to be set.
 * All dynamic values are printed with e().
 */
$officer = Auth::user();
$links = $officer
    ? [
        'dashboard' => ['index.php',   'Dashboard'],
        'events'    => ['events.php',  'Events'],
        'checkin'   => ['checkin.php', 'Attendance Kiosk'],
        'records'   => ['records.php', 'Attendance Records'],
        'privacy'   => ['privacy.php', 'Privacy Notice'],
    ]
    : [
        'checkin' => ['checkin.php', 'Attendance Kiosk'],
        'privacy' => ['privacy.php', 'Privacy Notice'],
        'login'   => ['login.php',   'Officer Login'],
    ];
?>
<!doctype html>
<html lang="en">
<head>
  <meta charset="utf-8">
  <meta name="viewport" content="width=device-width, initial-scale=1">
  <meta name="csrf-token" content="<?= e(App::csrfToken()) ?>">
  <title><?= e($title) ?> · OrgTrack CHMSU</title>
  <link rel="icon" href="assets/img/logo.svg" type="image/svg+xml">
  <link rel="stylesheet" href="assets/vendor/bootstrap/bootstrap.min.css">
  <link rel="stylesheet" href="assets/css/style.css">
</head>
<body>
<a class="visually-hidden-focusable skip-link" href="#main">Skip to content</a>

<header class="topbar d-lg-none">
  <button class="btn btn-icon" type="button" data-bs-toggle="offcanvas" data-bs-target="#sidebar" aria-controls="sidebar" aria-label="Open menu">
    <span class="burger"></span>
  </button>
  <span class="brand-sm"><img src="assets/img/logo.svg" alt="" width="26" height="26"> OrgTrack</span>
</header>

<div class="shell">
  <aside class="offcanvas-lg offcanvas-start sidebar" tabindex="-1" id="sidebar" aria-label="Main navigation">
    <div class="offcanvas-header d-lg-none">
      <span class="brand"><img src="assets/img/logo.svg" alt="" width="30" height="30"> OrgTrack</span>
      <button type="button" class="btn-close btn-close-white" data-bs-dismiss="offcanvas" data-bs-target="#sidebar" aria-label="Close menu"></button>
    </div>
    <div class="offcanvas-body flex-column">
      <div class="brand d-none d-lg-flex">
        <img src="assets/img/logo.svg" alt="" width="34" height="34">
        <div><strong>OrgTrack</strong><small>CHMSU Events &amp; Attendance</small></div>
      </div>
      <nav class="nav flex-column side-nav">
        <?php foreach ($links as $key => [$href, $label]): ?>
          <a class="nav-link<?= $nav === $key ? ' active' : '' ?>" href="<?= e($href) ?>"<?= $nav === $key ? ' aria-current="page"' : '' ?>><?= e($label) ?></a>
        <?php endforeach; ?>
      </nav>
      <?php if ($officer): ?>
        <div class="who mt-auto">
          <div class="small text-uppercase opacity-75">Signed in</div>
          <div class="fw-semibold"><?= e($officer['full_name']) ?></div>
          <div class="small opacity-75"><?= e($officer['org']) ?> · <?= e(ucfirst($officer['role'])) ?></div>
          <form method="post" action="logout.php" class="mt-2">
            <?= App::csrfField() ?>
            <button class="btn btn-sm btn-outline-light w-100" type="submit">Log out</button>
          </form>
        </div>
      <?php endif; ?>
    </div>
  </aside>

  <main id="main" class="content">
    <?php foreach (App::takeFlashes() as $f): ?>
      <div class="alert alert-<?= e($f['type']) ?> alert-dismissible fade show" role="alert">
        <?= e($f['message']) ?>
        <button type="button" class="btn-close" data-bs-dismiss="alert" aria-label="Close"></button>
      </div>
    <?php endforeach; ?>

<?php
/**
 * Attendance records (log retrieval): filter by event, status and a
 * free-text search on student number or name. Admins may remove a log
 * (e.g. when a student withdraws consent under RA 10173).
 */
declare(strict_types=1);
require __DIR__ . '/src/bootstrap.php';
Auth::requireLogin();

$isAdmin = Auth::user()['role'] === 'admin';

if ($_SERVER['REQUEST_METHOD'] === 'POST' && ($_POST['do'] ?? '') === 'delete_log') {
    if (!$isAdmin) {
        App::flash('danger', 'Only administrators can remove attendance logs.');
    } elseif (!App::checkCsrf()) {
        App::flash('danger', 'Security token expired. Nothing was removed.');
    } elseif (AttendanceService::deleteLog((int) ($_POST['log_id'] ?? 0))) {
        App::flash('success', 'Attendance log removed.');
    }
    App::redirect('records.php?' . http_build_query(array_filter([
        'event_id' => $_POST['event_id'] ?? null, 'q' => $_POST['q'] ?? null, 'state' => $_POST['state'] ?? null,
    ])));
}

$eventId = (int) ($_GET['event_id'] ?? 0);
$q       = trim((string) ($_GET['q'] ?? ''));
$state   = in_array($_GET['state'] ?? '', ['inside', 'out'], true) ? $_GET['state'] : '';
$logs    = AttendanceService::search($eventId, $q, $state);
$events  = EventRepository::all();

$fmtTime = fn (?string $t) => $t ? date('g:i A', strtotime($t)) : null;

$title = 'Attendance Records';
$nav = 'records';
require __DIR__ . '/templates/layout_top.php';
?>
<div class="page-head">
  <div>
    <h1>Attendance Records</h1>
    <p><?= count($logs) ?> record<?= count($logs) === 1 ? '' : 's' ?> found.</p>
  </div>
</div>

<form class="panel p-3 mb-3 filters" method="get">
  <div class="row g-2 align-items-end">
    <div class="col-md-5">
      <label class="form-label small" for="event_id">Event</label>
      <select class="form-select" id="event_id" name="event_id">
        <option value="0">All events</option>
        <?php foreach ($events as $ev): ?>
          <option value="<?= (int) $ev['event_id'] ?>" <?= $eventId === (int) $ev['event_id'] ? 'selected' : '' ?>><?= e($ev['acronym'] . ' · ' . $ev['title']) ?></option>
        <?php endforeach; ?>
      </select>
    </div>
    <div class="col-md-3">
      <label class="form-label small" for="q">Student no. or name</label>
      <input class="form-control" id="q" name="q" type="search" value="<?= e($q) ?>">
    </div>
    <div class="col-7 col-md-2">
      <label class="form-label small" for="state">Status</label>
      <select class="form-select" id="state" name="state">
        <option value="">Any</option>
        <option value="inside" <?= $state === 'inside' ? 'selected' : '' ?>>Still inside</option>
        <option value="out" <?= $state === 'out' ? 'selected' : '' ?>>Timed out</option>
      </select>
    </div>
    <div class="col-5 col-md-2 d-grid">
      <button class="btn btn-navy" type="submit">Filter</button>
    </div>
  </div>
</form>

<div class="panel p-0">
  <div class="table-responsive-stack">
    <table class="table align-middle mb-0">
      <thead>
        <tr>
          <th scope="col">Student</th>
          <th scope="col">Course</th>
          <th scope="col">Event</th>
          <th scope="col">Time in</th>
          <th scope="col">Time out</th>
          <th scope="col">Duration</th>
          <th scope="col">Consent</th>
          <?php if ($isAdmin): ?><th scope="col" class="text-end">Action</th><?php endif; ?>
        </tr>
      </thead>
      <tbody>
      <?php if (!$logs): ?>
        <tr><td colspan="8" class="text-center text-secondary py-4">No attendance records match these filters.</td></tr>
      <?php endif; ?>
      <?php foreach ($logs as $log): ?>
        <tr>
          <td data-label="Student"><div>
            <span class="fw-semibold"><?= e($log['last_name'] . ', ' . $log['first_name']) ?></span><br>
            <span class="text-secondary small"><?= e($log['student_no']) ?></span>
          </div></td>
          <td data-label="Course"><?= e($log['college'] . ' · ' . $log['course'] . '-' . $log['year_level']) ?></td>
          <td data-label="Event"><div><?= e($log['title']) ?><br><span class="text-secondary small"><?= e($log['acronym'] . ' · ' . date('M j, Y', strtotime($log['event_date']))) ?></span></div></td>
          <td data-label="Time in"><?= e($fmtTime($log['time_in'])) ?></td>
          <td data-label="Time out"><?= $log['time_out'] ? e($fmtTime($log['time_out'])) : '<span class="badge text-bg-success">Inside</span>' ?></td>
          <td data-label="Duration"><?= $log['minutes'] !== null ? e(intdiv((int) $log['minutes'], 60) . 'h ' . ((int) $log['minutes'] % 60) . 'm') : '—' ?></td>
          <td data-label="Consent"><span class="badge text-bg-light border"><?= e($log['consent_version']) ?></span></td>
          <?php if ($isAdmin): ?>
            <td data-label="Action" class="text-md-end">
              <form method="post" data-confirm="Remove this attendance log for <?= e($log['first_name'] . ' ' . $log['last_name']) ?>?">
                <?= App::csrfField() ?>
                <input type="hidden" name="do" value="delete_log">
                <input type="hidden" name="log_id" value="<?= (int) $log['log_id'] ?>">
                <input type="hidden" name="event_id" value="<?= $eventId ?: '' ?>">
                <input type="hidden" name="q" value="<?= e($q) ?>">
                <input type="hidden" name="state" value="<?= e($state) ?>">
                <button class="btn btn-sm btn-outline-danger" type="submit">Remove</button>
              </form>
            </td>
          <?php endif; ?>
        </tr>
      <?php endforeach; ?>
      </tbody>
    </table>
  </div>
</div>
<?php require __DIR__ . '/templates/layout_bottom.php'; ?>

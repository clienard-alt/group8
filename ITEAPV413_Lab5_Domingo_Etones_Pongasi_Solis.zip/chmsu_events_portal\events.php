<?php
/**
 * Events: list/search (Read) and Delete.
 * Create and Update are handled by event_edit.php.
 */
declare(strict_types=1);
require __DIR__ . '/src/bootstrap.php';
Auth::requireLogin();

if ($_SERVER['REQUEST_METHOD'] === 'POST' && ($_POST['do'] ?? '') === 'delete') {
    if (!App::checkCsrf()) {
        App::flash('danger', 'Security token expired. Nothing was deleted.');
    } elseif (EventRepository::delete((int) ($_POST['event_id'] ?? 0))) {
        App::flash('success', 'Event deleted together with its attendance logs.');
    } else {
        App::flash('warning', 'That event no longer exists.');
    }
    App::redirect('events.php'); // Post/Redirect/Get
}

$q = trim((string) ($_GET['q'] ?? ''));
$events = EventRepository::all($q);
$badge = ['Upcoming' => 'text-bg-info', 'Ongoing' => 'text-bg-success', 'Completed' => 'text-bg-secondary'];

$title = 'Events';
$nav = 'events';
require __DIR__ . '/templates/layout_top.php';
?>
<div class="page-head">
  <div>
    <h1>Events</h1>
    <p><?= count($events) ?> event<?= count($events) === 1 ? '' : 's' ?><?= $q !== '' ? ' matching “' . e($q) . '”' : ' registered' ?>.</p>
  </div>
  <a class="btn btn-gold" href="event_edit.php">+ New event</a>
</div>

<form class="search-bar mb-3" method="get" role="search">
  <label class="visually-hidden" for="q">Search events</label>
  <input class="form-control" id="q" name="q" type="search" placeholder="Search title, venue or organization" value="<?= e($q) ?>">
  <button class="btn btn-outline-navy" type="submit">Search</button>
  <?php if ($q !== ''): ?><a class="btn btn-link" href="events.php">Clear</a><?php endif; ?>
</form>

<div class="panel p-0">
  <div class="table-responsive-stack">
    <table class="table table-hover align-middle mb-0">
      <thead>
        <tr>
          <th scope="col">Event</th>
          <th scope="col">Organization</th>
          <th scope="col">Schedule</th>
          <th scope="col">Venue</th>
          <th scope="col" class="text-center">Attendance</th>
          <th scope="col">Status</th>
          <th scope="col" class="text-end">Actions</th>
        </tr>
      </thead>
      <tbody>
      <?php if (!$events): ?>
        <tr><td colspan="7" class="text-center text-secondary py-4">No events found.</td></tr>
      <?php endif; ?>
      <?php foreach ($events as $ev): ?>
        <tr>
          <td data-label="Event" class="fw-semibold"><?= e($ev['title']) ?></td>
          <td data-label="Organization"><span class="org-tag"><?= e($ev['acronym']) ?></span></td>
          <td data-label="Schedule"><div>
            <?= e(date('M j, Y', strtotime($ev['event_date']))) ?><br>
            <span class="text-secondary small"><?= e(date('g:i A', strtotime($ev['start_time'])) . ' – ' . date('g:i A', strtotime($ev['end_time']))) ?></span>
          </div></td>
          <td data-label="Venue"><?= e($ev['venue']) ?></td>
          <td data-label="Attendance" class="text-md-center"><?= (int) $ev['attendees'] ?> / <?= (int) $ev['capacity'] ?></td>
          <td data-label="Status"><span class="badge <?= e($badge[$ev['status']]) ?>"><?= e($ev['status']) ?></span></td>
          <td data-label="Actions" class="text-md-end">
            <div class="d-inline-flex gap-1">
              <a class="btn btn-sm btn-outline-navy" href="records.php?event_id=<?= (int) $ev['event_id'] ?>">Logs</a>
              <a class="btn btn-sm btn-outline-navy" href="event_edit.php?id=<?= (int) $ev['event_id'] ?>">Edit</a>
              <form method="post" class="d-inline" data-confirm="Delete “<?= e($ev['title']) ?>” and its <?= (int) $ev['attendees'] ?> attendance log(s)?">
                <?= App::csrfField() ?>
                <input type="hidden" name="do" value="delete">
                <input type="hidden" name="event_id" value="<?= (int) $ev['event_id'] ?>">
                <button class="btn btn-sm btn-outline-danger" type="submit">Delete</button>
              </form>
            </div>
          </td>
        </tr>
      <?php endforeach; ?>
      </tbody>
    </table>
  </div>
</div>
<?php require __DIR__ . '/templates/layout_bottom.php'; ?>

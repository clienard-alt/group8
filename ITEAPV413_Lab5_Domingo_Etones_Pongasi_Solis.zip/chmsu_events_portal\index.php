<?php
/**
 * Live dashboard. The page is only a skeleton: assets/js/dashboard.js
 * requests api/dashboard.php with the Fetch API every 5 seconds and
 * updates the numbers, bars and activity feed without a page reload.
 */
declare(strict_types=1);
require __DIR__ . '/src/bootstrap.php';
Auth::requireLogin();

$title = 'Dashboard';
$nav = 'dashboard';
$scripts = ['assets/js/dashboard.js'];
require __DIR__ . '/templates/layout_top.php';
?>
<div class="page-head">
  <div>
    <h1>Dashboard</h1>
    <p>Attendance across all organizations, updated live.</p>
  </div>
  <div class="live-pill" id="liveStatus" role="status" aria-live="polite">
    <span class="dot"></span><span id="liveText">Connecting…</span>
  </div>
</div>

<section class="row g-3 mb-4" aria-label="Summary">
  <?php foreach ([
      ['inside',   'Inside now',        'Students timed in to today\'s events'],
      ['today',    'Time-ins today',    'All events held today'],
      ['logs',     'Attendance logs',   'Every event, all time'],
      ['upcoming', 'Upcoming events',   'Today and later'],
  ] as [$key, $label, $hint]): ?>
    <div class="col-6 col-xl-3">
      <div class="stat">
        <div class="stat-label"><?= e($label) ?></div>
        <div class="stat-value" data-stat="<?= e($key) ?>">–</div>
        <div class="stat-hint"><?= e($hint) ?></div>
      </div>
    </div>
  <?php endforeach; ?>
</section>

<div class="row g-4">
  <section class="col-xl-8">
    <div class="panel">
      <div class="panel-head">
        <h2>Events nearest to today</h2>
        <a class="btn btn-sm btn-outline-navy" href="events.php">Manage events</a>
      </div>
      <ul class="event-bars list-unstyled mb-0" id="eventBars">
        <li class="text-secondary p-3">Loading events…</li>
      </ul>
    </div>
  </section>

  <section class="col-xl-4">
    <div class="panel mb-4">
      <div class="panel-head"><h2>Attendance by college</h2></div>
      <ul class="college-bars list-unstyled mb-0" id="collegeBars"></ul>
    </div>
    <div class="panel">
      <div class="panel-head"><h2>Recent activity</h2></div>
      <ol class="feed list-unstyled mb-0" id="activityFeed"></ol>
    </div>
  </section>
</div>
<?php require __DIR__ . '/templates/layout_bottom.php'; ?>

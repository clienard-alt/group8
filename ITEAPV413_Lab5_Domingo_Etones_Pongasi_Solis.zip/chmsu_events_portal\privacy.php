<?php
/**
 * Privacy notice under Republic Act No. 10173 (Data Privacy Act of 2012).
 */
declare(strict_types=1);
require __DIR__ . '/src/bootstrap.php';

$title = 'Privacy Notice';
$nav = 'privacy';
require __DIR__ . '/templates/layout_top.php';
?>
<div class="page-head">
  <div>
    <h1>Privacy Notice</h1>
    <p>How OrgTrack handles your personal information.</p>
  </div>
</div>

<article class="panel p-3 p-md-4 prose">
  <p>Carlos Hilado Memorial State University (CHMSU) and its recognized student organizations respect your
  privacy. This notice explains how the OrgTrack attendance portal processes personal information in
  compliance with <strong>Republic Act No. 10173, the Data Privacy Act of 2012</strong>, its Implementing
  Rules and Regulations, and issuances of the National Privacy Commission (NPC).</p>

  <h2>1. Information we collect</h2>
  <ul>
    <li>Student number, first name and last name</li>
    <li>College, course and year level</li>
    <li>Event attended, time-in and time-out</li>
    <li>The version and time of the consent you gave</li>
  </ul>
  <p>We do not collect sensitive personal information such as health, religion, or government ID numbers.</p>

  <h2>2. Purpose and legal basis</h2>
  <p>Your data is processed only to record and verify attendance at organization events and to produce
  attendance summaries for the organization and the Office of Student Affairs. Processing is based on your
  <strong>consent</strong>, given through the checkbox on the attendance kiosk (Sec. 12(a), RA 10173).
  Attendance cannot be recorded without it.</p>

  <h2>3. Who can see your data</h2>
  <p>Only authenticated organization officers and the portal administrator. Your data is not sold or
  shared with third parties outside the University.</p>

  <h2>4. How we protect it</h2>
  <ul>
    <li>Database access uses parameterized (prepared) statements to prevent SQL injection.</li>
    <li>All output is escaped to prevent cross-site scripting.</li>
    <li>Officer passwords are hashed; officer pages require login and are protected from cross-site request forgery.</li>
  </ul>

  <h2>5. Retention</h2>
  <p>Attendance records are kept for one academic year after the event, then deleted or anonymized.</p>

  <h2>6. Your rights as a data subject</h2>
  <p>Under Sections 16 to 18 of RA 10173 you have the right to be informed, to access, to object, to
  rectify, to erasure or blocking, to data portability, and to file a complaint with the National Privacy
  Commission. You may withdraw your consent at any time; your attendance log will then be removed.</p>

  <h2>7. Contact</h2>
  <p>CHMSU Data Protection Officer, Office of the President, Carlos Hilado Memorial State University,
  Talisay City, Negros Occidental.</p>
</article>
<?php require __DIR__ . '/templates/layout_bottom.php'; ?>

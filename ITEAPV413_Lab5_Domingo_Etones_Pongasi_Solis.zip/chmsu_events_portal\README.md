# OrgTrack: CHMSU Student Organization & Event Attendance Web Portal

ITEAPV413 · Chapter 5 Laboratory Activity
Group: Domingo, Etones, Pongasi, Soles

OrgTrack is a three-tier web application for recording student attendance at
organization events. Officers log in to register events and view records;
students use a public kiosk page to **time in** and **time out**.

## Stack

| Tier | Technology | Files |
|------|------------|-------|
| Presentation | HTML5, Bootstrap 5.3 (local copy), vanilla JS (Fetch API) | `*.php` pages, `templates/`, `assets/` |
| Business logic | PHP 8.2, PDO | `src/` classes, `api/` JSON endpoints |
| Data | MySQL 8 / MariaDB 10.4+ (InnoDB) | `../database/schema.sql` |

## Installation (XAMPP)

1. Copy the `chmsu_events_portal` folder to `C:\xampp\htdocs\`.
2. Start **Apache** and **MySQL** in the XAMPP Control Panel.
3. Import the database:
   `C:\xampp\mysql\bin\mysql.exe -u root < database\schema.sql`
   (or phpMyAdmin → Import → `schema.sql`).
4. If your MySQL user/password/port differ, edit `config/config.php`
   or set the `DB_HOST`, `DB_PORT`, `DB_NAME`, `DB_USER`, `DB_PASS` environment variables.
5. Open `http://localhost/chmsu_events_portal/`.

Test accounts (seed data):

| Username | Password | Role |
|----------|----------|------|
| `admin` | `OrgTrack@2026` | admin (can also remove attendance logs) |
| `jpcs.officer` | `Officer@2026` | officer |

Students need no account: open **Attendance Kiosk** (`checkin.php`).
The kiosk only lists events dated **today**, so create an event for today's
date to try time-in / time-out.

## Pages

| Page | Access | Purpose |
|------|--------|---------|
| `index.php` | officer | Live dashboard (Fetch API, refreshes every 5 s) |
| `events.php` | officer | List, search and delete events |
| `event_edit.php` | officer | Create / update an event |
| `records.php` | officer | Attendance log retrieval: filter by event, status, student |
| `checkin.php` | public | Time-in / time-out kiosk with RA 10173 consent |
| `privacy.php` | public | Full privacy notice |
| `env_check.php` | officer | Environment verification |
| `api/dashboard.php` | officer | GET → JSON dashboard data |
| `api/attendance.php` | public + CSRF | POST → time-in / time-out (JSON) |

## Security summary

- **SQL injection**: every query goes through `Database::run()` → `prepare()` + `execute()`,
  with emulated prepares disabled.
- **XSS**: every echoed value passes through `e()` (`htmlspecialchars`, ENT_QUOTES, UTF-8);
  dashboard JS inserts data with `textContent`; JSON is encoded with `JSON_HEX_TAG`;
  a Content-Security-Policy forbids inline scripts.
- **CSRF**: per-session token on every POST form and on Fetch requests (`X-CSRF-Token`).
- **Authentication**: bcrypt password hashes, session ID regenerated on login,
  lockout after 5 failed attempts, HttpOnly session cookie.
- **Duplicate prevention**: `UNIQUE (event_id, student_id)` in the database plus a friendly message in PHP.
- **RA 10173**: consent checkbox required, validated in PHP, stored with version/time,
  and enforced by `CHECK (consent_given = 1)`.

## Tests

With the site running:

```
php tests/run_tests.php http://localhost/chmsu_events_portal
```

The suite runs 40 functional, security and database checks and writes
`tests/test_log.txt` and `tests/test_results.json`. Re-import `schema.sql`
afterwards to restore the seed data.

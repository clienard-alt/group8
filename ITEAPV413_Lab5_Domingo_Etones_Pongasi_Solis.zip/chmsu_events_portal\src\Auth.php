<?php
/**
 * Officer authentication (session based).
 */
declare(strict_types=1);

final class Auth
{
    public static function user(): ?array
    {
        return $_SESSION['officer'] ?? null;
    }

    public static function check(): bool
    {
        return isset($_SESSION['officer']);
    }

    /** Page guard: send guests to the login form. */
    public static function requireLogin(): void
    {
        if (!self::check()) {
            App::redirect('login.php?next=' . rawurlencode(basename($_SERVER['SCRIPT_NAME'])));
        }
    }

    /** API guard: answer 401 JSON instead of redirecting. */
    public static function requireLoginJson(): void
    {
        if (!self::check()) {
            App::json(['ok' => false, 'message' => 'Please log in as an officer.'], 401);
        }
    }

    public static function lockedOutFor(): int
    {
        $until = $_SESSION['login_locked_until'] ?? 0;
        return max(0, $until - time());
    }

    /**
     * Verifies credentials with a prepared statement and password_verify().
     * After too many failures the session is locked for a short time.
     */
    public static function attempt(string $username, string $password): bool
    {
        $sec = App::config('security');
        if (self::lockedOutFor() > 0) {
            return false;
        }

        $row = Database::run(
            'SELECT o.officer_id, o.username, o.password_hash, o.full_name, o.role, o.org_id, g.acronym
               FROM officers o JOIN organizations g ON g.org_id = o.org_id
              WHERE o.username = ?',
            [$username]
        )->fetch();

        if (!$row || !password_verify($password, $row['password_hash'])) {
            $_SESSION['login_failures'] = ($_SESSION['login_failures'] ?? 0) + 1;
            if ($_SESSION['login_failures'] >= $sec['max_login_attempts']) {
                $_SESSION['login_locked_until'] = time() + $sec['lockout_seconds'];
                $_SESSION['login_failures'] = 0;
            }
            return false;
        }

        session_regenerate_id(true);            // prevent session fixation
        unset($_SESSION['login_failures'], $_SESSION['login_locked_until']);
        $_SESSION['officer'] = [
            'id'        => (int) $row['officer_id'],
            'username'  => $row['username'],
            'full_name' => $row['full_name'],
            'role'      => $row['role'],
            'org'       => $row['acronym'],
        ];
        Database::run('UPDATE officers SET last_login_at = NOW() WHERE officer_id = ?', [$row['officer_id']]);
        return true;
    }

    public static function logout(): void
    {
        $_SESSION = [];
        session_regenerate_id(true);
    }
}

<?php
/**
 * Small application kernel: configuration, session, security headers,
 * CSRF protection, output escaping and JSON responses.
 */
declare(strict_types=1);

final class App
{
    private static array $config = [];

    public static function boot(): void
    {
        self::$config = require __DIR__ . '/../config/config.php';
        date_default_timezone_set(self::$config['app']['timezone']);

        if (session_status() !== PHP_SESSION_ACTIVE) {
            session_set_cookie_params([
                'lifetime' => 0,
                'path'     => '/',
                'httponly' => true,          // JS cannot read the cookie
                'samesite' => 'Lax',
                'secure'   => !empty($_SERVER['HTTPS']),
            ]);
            ini_set('session.use_strict_mode', '1');
            ini_set('session.use_only_cookies', '1');
            session_name('ORGTRACKSESS');
            session_start();
        }

        // Defense-in-depth headers. All JS/CSS are local files, so inline
        // scripts are not allowed at all: an injected <script> cannot run.
        header("Content-Security-Policy: default-src 'self'; script-src 'self'; style-src 'self'; img-src 'self' data:; object-src 'none'; base-uri 'self'; form-action 'self'; frame-ancestors 'none'");
        header('X-Content-Type-Options: nosniff');
        header('X-Frame-Options: DENY');
        header('Referrer-Policy: strict-origin-when-cross-origin');
    }

    public static function config(string $section): array
    {
        return self::$config[$section];
    }

    // ------------------------------------------------------------------
    // CSRF: one random token per session, checked on every state change
    // ------------------------------------------------------------------
    public static function csrfToken(): string
    {
        if (empty($_SESSION['csrf_token'])) {
            $_SESSION['csrf_token'] = bin2hex(random_bytes(32));
        }
        return $_SESSION['csrf_token'];
    }

    public static function csrfField(): string
    {
        return '<input type="hidden" name="csrf_token" value="' . e(self::csrfToken()) . '">';
    }

    /** Accepts the token from a form field or the X-CSRF-Token header (Fetch). */
    public static function checkCsrf(): bool
    {
        $sent = $_POST['csrf_token'] ?? ($_SERVER['HTTP_X_CSRF_TOKEN'] ?? '');
        return is_string($sent) && !empty($_SESSION['csrf_token'])
            && hash_equals($_SESSION['csrf_token'], $sent);
    }

    // ------------------------------------------------------------------
    // Flash messages (shown once after a redirect)
    // ------------------------------------------------------------------
    public static function flash(string $type, string $message): void
    {
        $_SESSION['flash'][] = ['type' => $type, 'message' => $message];
    }

    public static function takeFlashes(): array
    {
        $f = $_SESSION['flash'] ?? [];
        unset($_SESSION['flash']);
        return $f;
    }

    public static function redirect(string $to): never
    {
        header('Location: ' . $to);
        exit;
    }

    public static function json(array $data, int $status = 200): never
    {
        http_response_code($status);
        header('Content-Type: application/json; charset=utf-8');
        header('Cache-Control: no-store');
        // JSON_HEX_* turns < > & ' " into \u00XX so JSON can never break out
        // into HTML even if a client mistakenly inserts it as markup.
        echo json_encode($data, JSON_HEX_TAG | JSON_HEX_AMP | JSON_HEX_APOS | JSON_HEX_QUOT | JSON_UNESCAPED_UNICODE);
        exit;
    }
}

/**
 * XSS defense: escape any dynamic value for an HTML context.
 * Every variable echoed in a template goes through this function.
 */
function e(mixed $value): string
{
    return htmlspecialchars((string) $value, ENT_QUOTES | ENT_SUBSTITUTE, 'UTF-8');
}

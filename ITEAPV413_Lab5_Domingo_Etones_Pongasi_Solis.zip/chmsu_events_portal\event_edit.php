<?php
/**
 * Event registration form: Create (no id) and Update (?id=N).
 */
declare(strict_types=1);
require __DIR__ . '/src/bootstrap.php';
Auth::requireLogin();

$id = (int) ($_GET['id'] ?? 0);
$existing = $id ? EventRepository::find($id) : null;
if ($id && !$existing) {
    App::flash('warning', 'Event not found.');
    App::redirect('events.php');
}

$data = $existing ?? [
    'org_id' => '', 'title' => '', 'description' => '', 'venue' => '',
    'event_date' => date('Y-m-d'), 'start_time' => '08:00', 'end_time' => '12:00', 'capacity' => 100,
];
$errors = [];

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    if (!App::checkCsrf()) {
        $errors['form'] = 'Security token expired. Please submit again.';
        $data = array_merge($data, $_POST);
    } else {
        [$data, $errors] = EventRepository::validate($_POST);
        if (!$errors) {
            try {
                if ($existing) {
                    EventRepository::update($id, $data);
                    App::flash('success', 'Event updated.');
                } else {
                    EventRepository::create($data, Auth::user()['id']);
                    App::flash('success', 'Event created. It now appears on the dashboard.');
                }
                App::redirect('events.php');
            } catch (PDOException $ex) {
                if ($ex->getCode() !== '23000') {
                    throw $ex;
                }
                // uq_events_org_title_date: same org cannot register the same title twice on one day
                $errors['title'] = 'This organization already has an event with this title on that date.';
            }
        }
    }
}

$orgs = EventRepository::organizations();
$invalid = fn (string $f) => isset($errors[$f]) ? ' is-invalid' : '';
$hm = fn ($t) => substr((string) $t, 0, 5);

$title = $existing ? 'Edit Event' : 'New Event';
$nav = 'events';
require __DIR__ . '/templates/layout_top.php';
?>
<div class="page-head">
  <div>
    <h1><?= e($title) ?></h1>
    <p><?= $existing ? 'Update the details of “' . e($existing['title']) . '”.' : 'Register a new organization event.' ?></p>
  </div>
  <a class="btn btn-outline-navy" href="events.php">Back to events</a>
</div>

<form method="post" class="panel p-3 p-md-4" novalidate>
  <?= App::csrfField() ?>
  <?php if ($errors): ?>
    <div class="alert alert-danger" role="alert"><?= e($errors['form'] ?? 'Please fix the fields marked in red.') ?></div>
  <?php endif; ?>

  <div class="row g-3">
    <div class="col-md-8">
      <label class="form-label" for="title">Event title</label>
      <input class="form-control<?= $invalid('title') ?>" id="title" name="title" maxlength="150" required value="<?= e($data['title']) ?>">
      <div class="invalid-feedback"><?= e($errors['title'] ?? '') ?></div>
    </div>
    <div class="col-md-4">
      <label class="form-label" for="org_id">Hosting organization</label>
      <select class="form-select<?= $invalid('org_id') ?>" id="org_id" name="org_id" required>
        <option value="">Select…</option>
        <?php foreach ($orgs as $o): ?>
          <option value="<?= (int) $o['org_id'] ?>" <?= (string) $data['org_id'] === (string) $o['org_id'] ? 'selected' : '' ?>><?= e($o['acronym']) ?></option>
        <?php endforeach; ?>
      </select>
      <div class="invalid-feedback"><?= e($errors['org_id'] ?? '') ?></div>
    </div>
    <div class="col-12">
      <label class="form-label" for="description">Description <span class="text-secondary">(optional)</span></label>
      <textarea class="form-control<?= $invalid('description') ?>" id="description" name="description" rows="3" maxlength="1000"><?= e($data['description'] ?? '') ?></textarea>
      <div class="invalid-feedback"><?= e($errors['description'] ?? '') ?></div>
    </div>
    <div class="col-md-6">
      <label class="form-label" for="venue">Venue</label>
      <input class="form-control<?= $invalid('venue') ?>" id="venue" name="venue" maxlength="120" required value="<?= e($data['venue']) ?>">
      <div class="invalid-feedback"><?= e($errors['venue'] ?? '') ?></div>
    </div>
    <div class="col-md-6">
      <label class="form-label" for="capacity">Capacity (max attendees)</label>
      <input class="form-control<?= $invalid('capacity') ?>" id="capacity" name="capacity" type="number" min="1" max="5000" required value="<?= e($data['capacity']) ?>">
      <div class="invalid-feedback"><?= e($errors['capacity'] ?? '') ?></div>
    </div>
    <div class="col-md-4">
      <label class="form-label" for="event_date">Date</label>
      <input class="form-control<?= $invalid('event_date') ?>" id="event_date" name="event_date" type="date" required value="<?= e($data['event_date']) ?>">
      <div class="invalid-feedback"><?= e($errors['event_date'] ?? '') ?></div>
    </div>
    <div class="col-6 col-md-4">
      <label class="form-label" for="start_time">Starts</label>
      <input class="form-control<?= $invalid('start_time') ?>" id="start_time" name="start_time" type="time" required value="<?= e($hm($data['start_time'])) ?>">
      <div class="invalid-feedback"><?= e($errors['start_time'] ?? '') ?></div>
    </div>
    <div class="col-6 col-md-4">
      <label class="form-label" for="end_time">Ends</label>
      <input class="form-control<?= $invalid('end_time') ?>" id="end_time" name="end_time" type="time" required value="<?= e($hm($data['end_time'])) ?>">
      <div class="invalid-feedback"><?= e($errors['end_time'] ?? '') ?></div>
    </div>
  </div>

  <div class="d-flex gap-2 justify-content-end mt-4">
    <a class="btn btn-light" href="events.php">Cancel</a>
    <button class="btn btn-gold" type="submit"><?= $existing ? 'Save changes' : 'Create event' ?></button>
  </div>
</form>
<?php require __DIR__ . '/templates/layout_bottom.php'; ?>

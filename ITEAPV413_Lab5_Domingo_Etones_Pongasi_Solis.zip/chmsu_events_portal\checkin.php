<?php
/**
 * Public attendance kiosk: students time in and time out of today's events.
 *
 * With JavaScript: assets/js/checkin.js posts to api/attendance.php with
 * the Fetch API and shows the result without reloading.
 * Without JavaScript: the form posts here and the same service is used.
 */
declare(strict_types=1);
require __DIR__ . '/src/bootstrap.php';

$events   = EventRepository::openToday();
$colleges = AttendanceService::colleges();
$result   = null;
$old      = [];

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $old = $_POST;
    if (!App::checkCsrf()) {
        $result = ['ok' => false, 'code' => 'csrf', 'message' => 'Security token expired. Please try again.'];
    } else {
        $result = ($_POST['action'] ?? 'in') === 'out'
            ? AttendanceService::timeOut($_POST)
            : AttendanceService::timeIn($_POST);
        if ($result['ok']) {
            $old = ['event_id' => $_POST['event_id'] ?? '']; // clear the form after success
        }
    }
}
$fieldError = fn (string $f) => $result['errors'][$f] ?? '';
$val = fn (string $f) => e($old[$f] ?? '');
$selectedEvent = (int) ($old['event_id'] ?? ($_GET['event'] ?? ($events[0]['event_id'] ?? 0)));
$alertClass = $result === null ? 'd-none' : ($result['ok'] ? 'alert-success' : ($result['code'] === 'duplicate' ? 'alert-warning' : 'alert-danger'));

$title = 'Attendance Kiosk';
$nav = 'checkin';
$scripts = ['assets/js/checkin.js'];
require __DIR__ . '/templates/layout_top.php';
?>
<div class="page-head">
  <div>
    <h1>Attendance Kiosk</h1>
    <p>Time in when you arrive and time out when you leave.</p>
  </div>
  <div class="clock" id="kioskClock" aria-hidden="true"><?= e(date('g:i A')) ?></div>
</div>

<?php if (!$events): ?>
  <div class="panel p-4 text-center">
    <h2 class="h5">No events are open today</h2>
    <p class="text-secondary mb-0">Attendance opens on the day of each event. Please check with the organizing officers.</p>
  </div>
<?php else: ?>
<div class="row g-4">
  <div class="col-lg-8">
    <form class="panel p-3 p-md-4" id="attendanceForm" method="post" action="checkin.php" novalidate>
      <?= App::csrfField() ?>

      <div id="formAlert" class="alert <?= e($alertClass) ?>" role="alert" aria-live="assertive" tabindex="-1"><?= $result ? e($result['message']) : '' ?></div>

      <fieldset class="mb-3">
        <legend class="form-label fw-semibold">I want to</legend>
        <div class="segmented" role="radiogroup">
          <input type="radio" class="btn-check" name="action" id="actIn" value="in" <?= ($old['action'] ?? 'in') !== 'out' ? 'checked' : '' ?>>
          <label class="btn" for="actIn">Time In</label>
          <input type="radio" class="btn-check" name="action" id="actOut" value="out" <?= ($old['action'] ?? '') === 'out' ? 'checked' : '' ?>>
          <label class="btn" for="actOut">Time Out</label>
        </div>
      </fieldset>

      <div class="mb-3">
        <label class="form-label" for="event_id">Event</label>
        <select class="form-select" id="event_id" name="event_id" required>
          <?php foreach ($events as $ev): ?>
            <option value="<?= (int) $ev['event_id'] ?>" <?= $selectedEvent === (int) $ev['event_id'] ? 'selected' : '' ?>>
              <?= e($ev['acronym'] . ' · ' . $ev['title'] . ' (' . date('g:i A', strtotime($ev['start_time'])) . ')') ?>
            </option>
          <?php endforeach; ?>
        </select>
      </div>

      <div class="row g-3">
        <div class="col-md-6">
          <label class="form-label" for="student_no">Student number</label>
          <input class="form-control <?= $fieldError('student_no') ? 'is-invalid' : '' ?>" id="student_no" name="student_no" placeholder="2024-01234" inputmode="numeric" maxlength="10" required value="<?= $val('student_no') ?>">
          <div class="invalid-feedback" data-for="student_no"><?= e($fieldError('student_no')) ?></div>
        </div>
        <div class="col-md-6">
          <label class="form-label" for="last_name">Last name</label>
          <input class="form-control <?= $fieldError('last_name') ? 'is-invalid' : '' ?>" id="last_name" name="last_name" autocomplete="family-name" maxlength="60" required value="<?= $val('last_name') ?>">
          <div class="invalid-feedback" data-for="last_name"><?= e($fieldError('last_name')) ?></div>
        </div>
      </div>

      <div id="timeInOnly">
        <div class="row g-3 mt-0">
          <div class="col-md-6">
            <label class="form-label" for="first_name">First name</label>
            <input class="form-control <?= $fieldError('first_name') ? 'is-invalid' : '' ?>" id="first_name" name="first_name" autocomplete="given-name" maxlength="60" value="<?= $val('first_name') ?>">
            <div class="invalid-feedback" data-for="first_name"><?= e($fieldError('first_name')) ?></div>
          </div>
          <div class="col-md-6">
            <label class="form-label" for="college_id">College</label>
            <select class="form-select <?= $fieldError('college_id') ? 'is-invalid' : '' ?>" id="college_id" name="college_id">
              <option value="">Select…</option>
              <?php foreach ($colleges as $c): ?>
                <option value="<?= (int) $c['college_id'] ?>" data-code="<?= e($c['code']) ?>" <?= (string) ($old['college_id'] ?? '') === (string) $c['college_id'] ? 'selected' : '' ?>><?= e($c['code'] . ' · ' . $c['name']) ?></option>
              <?php endforeach; ?>
            </select>
            <div class="invalid-feedback" data-for="college_id"><?= e($fieldError('college_id')) ?></div>
          </div>
          <div class="col-7 col-md-6">
            <label class="form-label" for="course">Course</label>
            <select class="form-select <?= $fieldError('course') ? 'is-invalid' : '' ?>" id="course" name="course">
              <option value="">Select…</option>
              <?php foreach (AttendanceService::COURSES as $code => $courses): ?>
                <optgroup label="<?= e($code) ?>" data-college="<?= e($code) ?>">
                  <?php foreach ($courses as $course): ?>
                    <option value="<?= e($course) ?>" <?= ($old['course'] ?? '') === $course ? 'selected' : '' ?>><?= e($course) ?></option>
                  <?php endforeach; ?>
                </optgroup>
              <?php endforeach; ?>
            </select>
            <div class="invalid-feedback" data-for="course"><?= e($fieldError('course')) ?></div>
          </div>
          <div class="col-5 col-md-6">
            <label class="form-label" for="year_level">Year level</label>
            <select class="form-select <?= $fieldError('year_level') ? 'is-invalid' : '' ?>" id="year_level" name="year_level">
              <option value="">Select…</option>
              <?php for ($y = 1; $y <= 5; $y++): ?>
                <option value="<?= $y ?>" <?= (string) ($old['year_level'] ?? '') === (string) $y ? 'selected' : '' ?>><?= $y ?></option>
              <?php endfor; ?>
            </select>
            <div class="invalid-feedback" data-for="year_level"><?= e($fieldError('year_level')) ?></div>
          </div>
        </div>

        <div class="consent-box mt-4">
          <h2 class="h6 mb-2">Data Privacy Consent (Republic Act No. 10173)</h2>
          <p class="small mb-2">
            By checking the box below, I consent to Carlos Hilado Memorial State University and the
            organizing student organization collecting and processing my student number, name, college,
            course, year level and time-in/time-out records for the sole purpose of monitoring attendance
            in this event, in accordance with Republic Act No. 10173, the Data Privacy Act of 2012, and its
            Implementing Rules and Regulations. I understand that my data will be kept only as long as
            necessary, will not be shared with third parties without my consent, and that I may exercise my
            rights to access, correct, object to and request erasure of my data by contacting the
            University's Data Protection Officer.
            <a href="privacy.php">Read the full privacy notice</a>.
          </p>
          <div class="form-check">
            <input class="form-check-input" type="checkbox" id="consent" name="consent" value="yes">
            <label class="form-check-label fw-semibold" for="consent">I have read and agree to the data privacy consent.</label>
          </div>
        </div>
      </div>

      <button class="btn btn-gold btn-lg w-100 mt-4" id="submitBtn" type="submit">
        <span class="label">Record Time In</span>
      </button>
    </form>
  </div>

  <aside class="col-lg-4">
    <div class="panel p-3 p-md-4">
      <h2 class="h6 text-uppercase text-secondary">How it works</h2>
      <ol class="steps">
        <li><strong>Time In</strong> on arrival. First-timers fill in all fields once; your record is reused for later events.</li>
        <li>Each student can time in <strong>only once</strong> per event.</li>
        <li><strong>Time Out</strong> when you leave, using only your student number and last name.</li>
      </ol>
      <div class="small text-secondary">Your record is linked to your student number. Contact the organizing officers if something is wrong.</div>
    </div>
  </aside>
</div>
<?php endif; ?>
<?php require __DIR__ . '/templates/layout_bottom.php'; ?>

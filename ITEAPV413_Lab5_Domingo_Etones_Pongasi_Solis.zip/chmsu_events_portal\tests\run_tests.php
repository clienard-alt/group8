<?php
/**
 * OrgTrack automated test suite (functional, security and database tests).
 *
 * Runs real HTTP requests against a running copy of the portal and checks
 * the database directly afterwards.
 *
 * Usage (from the chmsu_events_portal folder, with the server running):
 *   php tests/run_tests.php http://localhost/chmsu_events_portal
 *   php tests/run_tests.php http://127.0.0.1:8089
 *
 * Writes tests/test_log.txt and tests/test_results.json.
 * NOTE: re-import database/schema.sql afterwards to restore the seed data.
 */
declare(strict_types=1);

$base = rtrim($argv[1] ?? 'http://localhost/chmsu_events_portal', '/');
$cfg  = (require __DIR__ . '/../config/config.php')['db'];
$pdo  = new PDO(
    "mysql:host={$cfg['host']};port={$cfg['port']};dbname={$cfg['name']};charset=utf8mb4",
    $cfg['user'], $cfg['pass'],
    [PDO::ATTR_ERRMODE => PDO::ERRMODE_EXCEPTION, PDO::ATTR_DEFAULT_FETCH_MODE => PDO::FETCH_ASSOC, PDO::ATTR_EMULATE_PREPARES => false]
);
$pdo->exec("SET time_zone = '+08:00'");
date_default_timezone_set('Asia/Manila');

/** Minimal browser: keeps its own cookie jar (= its own PHP session). */
final class Client
{
    private string $jar;
    public string $csrf = '';

    public function __construct(private string $base)
    {
        $this->jar = tempnam(sys_get_temp_dir(), 'otc');
    }

    public function handle(string $method, string $path, array $data = [], array $headers = []): CurlHandle
    {
        $ch = curl_init($this->base . '/' . ltrim($path, '/'));
        curl_setopt_array($ch, [
            CURLOPT_RETURNTRANSFER => true,
            CURLOPT_HEADER         => true,
            CURLOPT_FOLLOWLOCATION => false,
            CURLOPT_COOKIEJAR      => $this->jar,
            CURLOPT_COOKIEFILE     => $this->jar,
            CURLOPT_HTTPHEADER     => $headers,
            CURLOPT_TIMEOUT        => 20,
        ]);
        if ($method === 'POST') {
            curl_setopt($ch, CURLOPT_POST, true);
            curl_setopt($ch, CURLOPT_POSTFIELDS, http_build_query($data));
        }
        return $ch;
    }

    public static function parse(CurlHandle $ch, string $raw): array
    {
        $size = curl_getinfo($ch, CURLINFO_HEADER_SIZE);
        return [
            'status'  => curl_getinfo($ch, CURLINFO_RESPONSE_CODE),
            'headers' => substr($raw, 0, $size),
            'body'    => substr($raw, $size),
        ];
    }

    public function request(string $method, string $path, array $data = [], array $headers = []): array
    {
        $ch = $this->handle($method, $path, $data, $headers);
        $raw = (string) curl_exec($ch);
        $r = self::parse($ch, $raw);
        if (preg_match('/<meta name="csrf-token" content="([a-f0-9]{64})"/', $r['body'], $m)) {
            $this->csrf = $m[1];
        }
        $r['json'] = json_decode($r['body'], true);
        return $r;
    }

    public function get(string $path): array { return $this->request('GET', $path); }

    public function post(string $path, array $data, bool $withToken = true): array
    {
        if ($withToken) {
            $data['csrf_token'] = $this->csrf;
        }
        return $this->request('POST', $path, $data);
    }

    /** POST to the Fetch API endpoint the same way checkin.js does. */
    public function api(array $data, ?string $token = null): array
    {
        return $this->request('POST', 'api/attendance.php', $data,
            ['X-CSRF-Token: ' . ($token ?? $this->csrf), 'Accept: application/json']);
    }

    public function login(string $user, string $pass): array
    {
        $this->get('login.php');
        return $this->post('login.php', ['username' => $user, 'password' => $pass]);
    }
}

$results = [];
function check(string $id, string $category, string $name, bool $ok, string $detail): void
{
    global $results;
    $results[] = compact('id', 'category', 'name', 'detail', 'ok');
    printf("[%s] %-4s %-13s %s\n       -> %s\n", $ok ? 'PASS' : 'FAIL', $id, $category, $name, $detail);
}
function scalar(PDO $pdo, string $sql, array $p = []): mixed
{
    $s = $pdo->prepare($sql);
    $s->execute($p);
    return $s->fetchColumn();
}
function location(array $r): string
{
    return preg_match('/^Location:\s*(\S+)/mi', $r['headers'], $m) ? $m[1] : '';
}

$today = date('Y-m-d');
echo "OrgTrack test run · " . date('Y-m-d H:i:s') . " (Asia/Manila)\nTarget: {$base}\n" . str_repeat('=', 72) . "\n";

// ---------------------------------------------------------------- ENVIRONMENT
check('T01', 'Environment', 'PHP 8.2+ with pdo_mysql',
    version_compare(PHP_VERSION, '8.2.0', '>=') && extension_loaded('pdo_mysql'),
    'PHP ' . PHP_VERSION . ', pdo_mysql ' . (extension_loaded('pdo_mysql') ? 'loaded' : 'missing'));

$tables = $pdo->query("SELECT TABLE_NAME FROM information_schema.TABLES WHERE TABLE_SCHEMA = DATABASE() ORDER BY TABLE_NAME")->fetchAll(PDO::FETCH_COLUMN);
$fks = (int) $pdo->query("SELECT COUNT(*) FROM information_schema.REFERENTIAL_CONSTRAINTS WHERE CONSTRAINT_SCHEMA = DATABASE()")->fetchColumn();
check('T02', 'Database', 'schema.sql created 6 tables and the foreign keys',
    count($tables) === 6 && $fks >= 7, 'tables: ' . implode(', ', $tables) . "; foreign keys: {$fks}");

// ---------------------------------------------------------------- AUTH
$guest = new Client($base);
$r = $guest->get('index.php');
check('T03', 'Auth', 'Guest opening the dashboard is redirected to login',
    $r['status'] === 302 && str_contains(location($r), 'login.php'), "HTTP {$r['status']} -> " . location($r));

$r = $guest->get('api/dashboard.php');
check('T04', 'Auth', 'Guest calling the dashboard API gets 401',
    $r['status'] === 401, "HTTP {$r['status']} " . trim($r['body']));

$bad = new Client($base);
$r = $bad->login('admin', 'wrong-password');
check('T05', 'Auth', 'Wrong password is rejected',
    $r['status'] === 200 && str_contains($r['body'], 'Incorrect username or password'), "HTTP {$r['status']}, error message shown");

$brute = new Client($base);
for ($i = 0; $i < 5; $i++) {
    $r = $brute->login('admin', 'guess' . $i);
}
$r = $brute->login('admin', 'OrgTrack@2026');   // correct password, but locked
check('T06', 'Auth', 'Login locks after 5 failed attempts',
    $r['status'] === 200 && str_contains($r['body'], 'Too many failed attempts'), 'correct password refused while locked');

$admin = new Client($base);
$r = $admin->login('admin', 'OrgTrack@2026');
check('T07', 'Auth', 'Admin logs in with a hashed password',
    $r['status'] === 302 && str_contains(location($r), 'index.php'), "HTTP {$r['status']} -> " . location($r));
$admin->get('index.php');

// ---------------------------------------------------------------- EVENT CRUD
$admin->get('event_edit.php');
$r = $admin->post('event_edit.php', [
    'title' => 'QA Test Seminar on Secure Coding', 'org_id' => 1, 'venue' => 'CCS AVR',
    'description' => 'Created by the test suite', 'event_date' => $today,
    'start_time' => '00:00', 'end_time' => '23:59', 'capacity' => 50,
]);
$eventId = (int) scalar($pdo, 'SELECT event_id FROM events WHERE title = ?', ['QA Test Seminar on Secure Coding']);
check('T08', 'CRUD', 'Create: officer registers a new event',
    $r['status'] === 302 && $eventId > 0, "HTTP {$r['status']}, new event_id={$eventId}");

$r = $admin->get('events.php?q=' . rawurlencode('Secure Coding'));
check('T09', 'CRUD', 'Read: event appears in the list and in search results',
    str_contains($r['body'], 'QA Test Seminar on Secure Coding') && str_contains($r['body'], '1 event matching'),
    'search "Secure Coding" -> 1 event');

$admin->get("event_edit.php?id={$eventId}");
$r = $admin->post("event_edit.php?id={$eventId}", [
    'title' => 'QA Test Seminar on Secure Coding', 'org_id' => 1, 'venue' => 'ICT Building Room 204',
    'description' => 'Updated', 'event_date' => $today, 'start_time' => '00:00', 'end_time' => '23:59', 'capacity' => 50,
]);
$venue = scalar($pdo, 'SELECT venue FROM events WHERE event_id = ?', [$eventId]);
check('T10', 'CRUD', 'Update: venue change is saved',
    $r['status'] === 302 && $venue === 'ICT Building Room 204', "venue in DB = '{$venue}'");

$r = $admin->post("event_edit.php?id={$eventId}", [
    'title' => 'QA Test Seminar on Secure Coding', 'org_id' => 1, 'venue' => 'Nowhere',
    'event_date' => $today, 'start_time' => '15:00', 'end_time' => '09:00', 'capacity' => 50,
]);
$venue2 = scalar($pdo, 'SELECT venue FROM events WHERE event_id = ?', [$eventId]);
check('T11', 'Validation', 'End time before start time is rejected',
    $r['status'] === 200 && str_contains($r['body'], 'End time must be later') && $venue2 === 'ICT Building Room 204',
    'error shown, database unchanged');

$admin->get('event_edit.php');
$r = $admin->post('event_edit.php', [
    'title' => 'QA Test Seminar on Secure Coding', 'org_id' => 1, 'venue' => 'Other room',
    'event_date' => $today, 'start_time' => '08:00', 'end_time' => '09:00', 'capacity' => 10,
]);
$dupCount = (int) scalar($pdo, 'SELECT COUNT(*) FROM events WHERE title = ?', ['QA Test Seminar on Secure Coding']);
check('T12', 'Validation', 'Same org cannot register the same title twice on one day',
    str_contains($r['body'], 'already has an event with this title') && $dupCount === 1, "rows with that title: {$dupCount}");

// ---------------------------------------------------------------- ATTENDANCE
$kiosk = new Client($base);
$kiosk->get('checkin.php');
$student = [
    'action' => 'in', 'event_id' => $eventId, 'student_no' => '2024-07771', 'first_name' => 'Juan Miguel',
    'last_name' => 'Ledesma', 'college_id' => 1, 'course' => 'BSIT', 'year_level' => 2, 'consent' => 'yes',
];
$r = $kiosk->api($student);
check('T13', 'Attendance', 'Time-in of a new student (Fetch API)',
    $r['status'] === 200 && ($r['json']['ok'] ?? false) === true, "HTTP {$r['status']} " . ($r['json']['message'] ?? ''));

$r = $kiosk->api($student);
$rows = (int) scalar($pdo, 'SELECT COUNT(*) FROM attendance_logs a JOIN students s USING (student_id) WHERE a.event_id = ? AND s.student_no = ?', [$eventId, '2024-07771']);
check('T14', 'Attendance', 'Duplicate time-in is blocked',
    $r['status'] === 409 && $rows === 1, "HTTP {$r['status']} \"" . ($r['json']['message'] ?? '') . "\"; rows = {$rows}");

$noConsent = ['student_no' => '2025-08802', 'first_name' => 'Bea', 'last_name' => 'Villareal'] + $student;
unset($noConsent['consent']);
$r = $kiosk->api($noConsent);
$exists = (int) scalar($pdo, 'SELECT COUNT(*) FROM students WHERE student_no = ?', ['2025-08802']);
check('T15', 'Privacy', 'Time-in without RA 10173 consent is refused',
    $r['status'] === 422 && ($r['json']['code'] ?? '') === 'consent_required' && $exists === 0,
    "HTTP {$r['status']} code=" . ($r['json']['code'] ?? '') . '; nothing stored');

$r = $kiosk->api(['student_no' => '24-1', 'first_name' => 'X', 'course' => 'BSA'] + $student);
check('T16', 'Validation', 'Bad student number, short name and wrong course are rejected',
    $r['status'] === 422 && isset($r['json']['errors']['student_no'], $r['json']['errors']['first_name'], $r['json']['errors']['course']),
    'errors: ' . implode(', ', array_keys($r['json']['errors'] ?? [])));

$r = $kiosk->api(['student_no' => '2023-01042', 'last_name' => 'Impostor', 'first_name' => 'Fake'] + $student);
check('T17', 'Attendance', 'Existing student number with a different last name is refused',
    ($r['json']['code'] ?? '') === 'mismatch', "HTTP {$r['status']} " . ($r['json']['message'] ?? ''));

$r = $kiosk->api(['action' => 'out', 'event_id' => $eventId, 'student_no' => '2024-07771', 'last_name' => 'ledesma']);
$out = scalar($pdo, 'SELECT a.time_out FROM attendance_logs a JOIN students s USING (student_id) WHERE a.event_id = ? AND s.student_no = ?', [$eventId, '2024-07771']);
check('T18', 'Attendance', 'Time-out is recorded',
    $r['status'] === 200 && $out !== null, "HTTP {$r['status']}, time_out = {$out}");

$r = $kiosk->api(['action' => 'out', 'event_id' => $eventId, 'student_no' => '2024-07771', 'last_name' => 'Ledesma']);
check('T19', 'Attendance', 'Second time-out is blocked',
    $r['status'] === 409, "HTTP {$r['status']} " . ($r['json']['message'] ?? ''));

$future = (int) scalar($pdo, 'SELECT event_id FROM events WHERE event_date > CURDATE() ORDER BY event_date LIMIT 1');
$r = $kiosk->api(['event_id' => $future, 'student_no' => '2024-07772'] + $student);
check('T20', 'Attendance', 'Time-in to an event that is not held today is refused',
    ($r['json']['code'] ?? '') === 'event_closed', "event {$future}: " . ($r['json']['message'] ?? ''));

// capacity: an event with room for only one attendee
$pdo->prepare('INSERT INTO events (org_id, title, venue, event_date, start_time, end_time, capacity) VALUES (2, ?, ?, CURDATE(), "00:00", "23:59", 1)')
    ->execute(['QA Capacity Check', 'Lab 1']);
$capId = (int) $pdo->lastInsertId();
$kiosk->api(['event_id' => $capId] + $student);
$r = $kiosk->api(['event_id' => $capId, 'student_no' => '2023-01177', 'last_name' => 'Bautista', 'first_name' => 'John Carlo', 'course' => 'BSCS', 'year_level' => 3] + $student);
check('T21', 'Attendance', 'Time-in is refused once the event is full',
    ($r['json']['code'] ?? '') === 'full', 'capacity 1: ' . ($r['json']['message'] ?? ''));

// concurrency: 6 identical time-ins fired at the same moment
$racer = ['student_no' => '2025-09913', 'first_name' => 'Racer', 'last_name' => 'Condition'] + $student;
$mh = curl_multi_init();
$handles = [];
for ($i = 0; $i < 6; $i++) {
    $c = new Client($base);
    $c->get('checkin.php');
    $h = $c->handle('POST', 'api/attendance.php', $racer + ['x' => $i], ['X-CSRF-Token: ' . $c->csrf]);
    curl_multi_add_handle($mh, $h);
    $handles[] = $h;
}
do {
    curl_multi_exec($mh, $running);
    curl_multi_select($mh);
} while ($running > 0);
$codes = array_map(fn ($h) => curl_getinfo($h, CURLINFO_RESPONSE_CODE), $handles);
$raceRows = (int) scalar($pdo, 'SELECT COUNT(*) FROM attendance_logs a JOIN students s USING (student_id) WHERE a.event_id = ? AND s.student_no = ?', [$eventId, '2025-09913']);
check('T22', 'Attendance', '6 simultaneous time-ins create exactly one log',
    $raceRows === 1, 'HTTP codes ' . implode(',', $codes) . "; rows = {$raceRows}");

// ---------------------------------------------------------------- DASHBOARD & RECORDS
$r = $admin->get('api/dashboard.php');
$dbLogs = (int) scalar($pdo, 'SELECT COUNT(*) FROM attendance_logs');
check('T23', 'Dashboard', 'Dashboard API returns live totals matching the database',
    $r['status'] === 200 && ($r['json']['totals']['logs'] ?? -1) === $dbLogs && str_contains($r['headers'], 'application/json'),
    "api logs = " . ($r['json']['totals']['logs'] ?? 'n/a') . ", database = {$dbLogs}");

$r = $admin->get("records.php?event_id={$eventId}&q=2024-07771");
check('T24', 'Records', 'Log retrieval by event and student number',
    str_contains($r['body'], '1 record found') && str_contains($r['body'], 'Ledesma, Juan Miguel'), "event {$eventId} + student 2024-07771 -> 1 record found");

$r = $admin->get("records.php?event_id=3&state=inside");
$inside = (int) scalar($pdo, 'SELECT COUNT(*) FROM attendance_logs WHERE event_id = 3 AND time_out IS NULL');
check('T25', 'Records', 'Filter by event and "still inside" status',
    str_contains($r['body'], "{$inside} record"), "expected {$inside} record(s)");

// ---------------------------------------------------------------- SECURITY
$r = $admin->get('records.php?q=' . rawurlencode("' OR '1'='1"));
check('T26', 'SQLi', "Search payload ' OR '1'='1 returns no rows",
    str_contains($r['body'], '0 records found'), 'treated as a literal search string');

$sqli = new Client($base);
$r = $sqli->login("admin' -- ", 'anything');
check('T27', 'SQLi', "Login payload admin' --  does not bypass authentication",
    $r['status'] === 200 && str_contains($r['body'], 'Incorrect username'), 'login refused');

$r = $kiosk->api(['student_no' => "2024-00001' OR 1=1 -- "] + $student);
check('T28', 'SQLi', 'Payload in student number is rejected by validation',
    $r['status'] === 422, "HTTP {$r['status']}");

$tablesAfter = (int) $pdo->query("SELECT COUNT(*) FROM information_schema.TABLES WHERE TABLE_SCHEMA = DATABASE()")->fetchColumn();
$r = $admin->get('events.php?q=' . rawurlencode("x'; DROP TABLE attendance_logs; -- "));
$tablesAfter2 = (int) $pdo->query("SELECT COUNT(*) FROM information_schema.TABLES WHERE TABLE_SCHEMA = DATABASE()")->fetchColumn();
check('T29', 'SQLi', 'Stacked-query DROP TABLE payload has no effect',
    $tablesAfter === 6 && $tablesAfter2 === 6 && $r['status'] === 200, "tables before/after: {$tablesAfter}/{$tablesAfter2}");

$admin->get('event_edit.php');
$admin->post('event_edit.php', [
    'title' => '<script>alert("XSS")</script>', 'org_id' => 3, 'venue' => '<img src=x onerror=alert(1)>',
    'event_date' => $today, 'start_time' => '00:00', 'end_time' => '23:59', 'capacity' => 20,
]);
$r = $admin->get('events.php');
check('T30', 'XSS', 'Script in event title is escaped by htmlspecialchars()',
    !str_contains($r['body'], '<script>alert') && str_contains($r['body'], '&lt;script&gt;alert(&quot;XSS&quot;)&lt;/script&gt;')
    && !str_contains($r['body'], '<img src=x'),
    'rendered as &lt;script&gt;alert(&quot;XSS&quot;)&lt;/script&gt;');

$r = $admin->get('api/dashboard.php');
$escaped = str_contains($r['body'], chr(92) . 'u003Cscript' . chr(92) . 'u003E');
check('T31', 'XSS', 'Script in JSON is hex-escaped (\\u003C) for the dashboard',
    !str_contains($r['body'], '<script>') && $escaped, 'raw <script> absent, \\u003Cscript\\u003E present');

$r = $kiosk->api(['student_no' => '2024-07799'] + $student, 'forged-token');
check('T32', 'CSRF', 'Fetch request with a forged CSRF token is refused',
    $r['status'] === 403, "HTTP {$r['status']} " . ($r['json']['message'] ?? ''));

$r = $admin->post('events.php', ['do' => 'delete', 'event_id' => $eventId], false);
$still = (int) scalar($pdo, 'SELECT COUNT(*) FROM events WHERE event_id = ?', [$eventId]);
check('T33', 'CSRF', 'Delete without a CSRF token is refused',
    $still === 1, 'event still exists');

$officer = new Client($base);
$officer->login('jpcs.officer', 'Officer@2026');
$officer->get('records.php');
$someLog = (int) scalar($pdo, 'SELECT MIN(log_id) FROM attendance_logs');
$officer->post('records.php', ['do' => 'delete_log', 'log_id' => $someLog]);
$logStill = (int) scalar($pdo, 'SELECT COUNT(*) FROM attendance_logs WHERE log_id = ?', [$someLog]);
check('T34', 'Access', 'Non-admin officer cannot delete attendance logs',
    $logStill === 1, "log {$someLog} still exists");

$r = $guest->get('checkin.php');
check('T35', 'Headers', 'CSP, X-Frame-Options and nosniff headers are sent',
    (bool) preg_match("/Content-Security-Policy:.*script-src 'self'/i", $r['headers'])
    && stripos($r['headers'], 'X-Frame-Options: DENY') !== false && stripos($r['headers'], 'nosniff') !== false,
    "script-src 'self', frame DENY, nosniff");

// ---------------------------------------------------------------- DATABASE CONSTRAINTS
try {
    $pdo->prepare('INSERT INTO attendance_logs (event_id, student_id, time_in, consent_given, consent_version, consent_at) VALUES (1, 6, NOW(), 0, "x", NOW())')->execute();
    $ok = false; $msg = 'row was inserted';
} catch (PDOException $ex) {
    $ok = true; $msg = 'rejected: ' . substr($ex->getMessage(), 0, 80);
}
check('T36', 'Constraint', 'CHECK refuses a log without consent', $ok, $msg);

try {
    $pdo->prepare('INSERT INTO attendance_logs (event_id, student_id, time_in, consent_given, consent_version, consent_at) VALUES (99999, 1, NOW(), 1, "x", NOW())')->execute();
    $ok = false; $msg = 'row was inserted';
} catch (PDOException $ex) {
    $ok = $ex->getCode() === '23000'; $msg = 'rejected: ' . substr($ex->getMessage(), 0, 80);
}
check('T37', 'Constraint', 'FOREIGN KEY refuses a log for a missing event', $ok, $msg);

$logsBefore = (int) scalar($pdo, 'SELECT COUNT(*) FROM attendance_logs WHERE event_id = ?', [$eventId]);
$admin->get('events.php');
$r = $admin->post('events.php', ['do' => 'delete', 'event_id' => $eventId]);
$logsAfter = (int) scalar($pdo, 'SELECT COUNT(*) FROM attendance_logs WHERE event_id = ?', [$eventId]);
$evGone = (int) scalar($pdo, 'SELECT COUNT(*) FROM events WHERE event_id = ?', [$eventId]) === 0;
check('T38', 'CRUD', 'Delete: event removed and its logs cascade',
    $evGone && $logsBefore > 0 && $logsAfter === 0, "logs before = {$logsBefore}, after = {$logsAfter}");

// ---------------------------------------------------------------- CODE SCAN
$offenders = [];
$it = new RecursiveIteratorIterator(new RecursiveDirectoryIterator(dirname(__DIR__) . '/src'));
foreach (array_merge(iterator_to_array($it), [new SplFileInfo(dirname(__DIR__) . '/env_check.php')]) as $f) {
    if ($f->getExtension() !== 'php') continue;
    foreach (file($f->getPathname()) as $n => $line) {
        // query()/exec() with a PHP variable inside the SQL string = possible injection
        if (preg_match('/->(query|exec)\(\s*["\'][^"\']*\$(?!t\b)/', $line)) {
            $offenders[] = basename($f->getPathname()) . ':' . ($n + 1);
        }
    }
}
check('T39', 'Code scan', 'No user input is concatenated into query()/exec()',
    $offenders === [], $offenders ? 'found: ' . implode(', ', $offenders) : 'all dynamic SQL goes through prepare()/execute()');

$r = $admin->post('logout.php', []);
$r2 = $admin->get('index.php');
check('T40', 'Auth', 'Logout ends the officer session',
    $r2['status'] === 302, "after logout index.php -> HTTP {$r2['status']}");

// ---------------------------------------------------------------- SUMMARY
$passed = count(array_filter($results, fn ($r) => $r['ok']));
echo str_repeat('=', 72) . "\nRESULT: {$passed} / " . count($results) . " tests passed\n";
file_put_contents(__DIR__ . '/test_results.json', json_encode($results, JSON_PRETTY_PRINT | JSON_UNESCAPED_SLASHES | JSON_UNESCAPED_UNICODE));
exit($passed === count($results) ? 0 : 1);

<?php
/**
 * Environment verification for the lab report: PHP version, extensions,
 * database server version and table row counts.
 * Officers only, because it reveals server details.
 */
declare(strict_types=1);
require __DIR__ . '/src/bootstrap.php';
Auth::requireLogin();

$checks = [];
$checks[] = ['PHP version 8.2 or newer', PHP_VERSION, version_compare(PHP_VERSION, '8.2.0', '>=')];
$checks[] = ['PDO extension', extension_loaded('pdo') ? 'loaded' : 'missing', extension_loaded('pdo')];
$checks[] = ['pdo_mysql driver', extension_loaded('pdo_mysql') ? 'loaded' : 'missing', extension_loaded('pdo_mysql')];
$checks[] = ['mbstring extension', extension_loaded('mbstring') ? 'loaded' : 'missing', extension_loaded('mbstring')];

$tables = [];
try {
    $pdo = Database::connection();
    $ver = (string) $pdo->query('SELECT VERSION()')->fetchColumn();
    $checks[] = ['Database connection', $ver, true];
    $checks[] = ['Real prepared statements (emulation off)',
        $pdo->getAttribute(PDO::ATTR_EMULATE_PREPARES) ? 'emulated' : 'native', !$pdo->getAttribute(PDO::ATTR_EMULATE_PREPARES)];
    foreach (['colleges', 'organizations', 'officers', 'events', 'students', 'attendance_logs'] as $t) {
        // Table names cannot be bound as parameters; they come from the fixed list above.
        $tables[$t] = (int) $pdo->query("SELECT COUNT(*) FROM `$t`")->fetchColumn();
    }
} catch (PDOException $ex) {
    $checks[] = ['Database connection', 'failed: check config/config.php', false];
}

$title = 'Environment Check';
$nav = '';
require __DIR__ . '/templates/layout_top.php';
?>
<div class="page-head">
  <div>
    <h1>Environment Check</h1>
    <p>Server stack verification · <?= e(date('F j, Y g:i A')) ?></p>
  </div>
</div>
<div class="row g-4">
  <div class="col-lg-7">
    <div class="panel p-0">
      <table class="table mb-0 align-middle">
        <thead><tr><th>Check</th><th>Result</th><th class="text-end">Status</th></tr></thead>
        <tbody>
        <?php foreach ($checks as [$name, $value, $ok]): ?>
          <tr>
            <td><?= e($name) ?></td>
            <td><code><?= e($value) ?></code></td>
            <td class="text-end"><span class="badge <?= $ok ? 'text-bg-success' : 'text-bg-danger' ?>"><?= $ok ? 'OK' : 'FAIL' ?></span></td>
          </tr>
        <?php endforeach; ?>
          <tr><td>Web server</td><td><code><?= e(PHP_SAPI . ' · ' . ($_SERVER['SERVER_SOFTWARE'] ?? 'unknown')) ?></code></td><td class="text-end"><span class="badge text-bg-success">OK</span></td></tr>
          <tr><td>Timezone</td><td><code><?= e(date_default_timezone_get()) ?></code></td><td class="text-end"><span class="badge text-bg-success">OK</span></td></tr>
        </tbody>
      </table>
    </div>
  </div>
  <div class="col-lg-5">
    <div class="panel p-0">
      <table class="table mb-0">
        <thead><tr><th>Table (chmsu_orgtrack_db)</th><th class="text-end">Rows</th></tr></thead>
        <tbody>
        <?php foreach ($tables as $t => $n): ?>
          <tr><td><code><?= e($t) ?></code></td><td class="text-end"><?= $n ?></td></tr>
        <?php endforeach; ?>
        </tbody>
      </table>
    </div>
  </div>
</div>
<?php require __DIR__ . '/templates/layout_bottom.php'; ?>

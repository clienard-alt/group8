<?php
/**
 * Entry point included by every page and API endpoint.
 * Loads the business-logic classes and boots the application.
 */
declare(strict_types=1);

require_once __DIR__ . '/App.php';
require_once __DIR__ . '/Database.php';
require_once __DIR__ . '/Auth.php';
require_once __DIR__ . '/EventRepository.php';
require_once __DIR__ . '/AttendanceService.php';

App::boot();

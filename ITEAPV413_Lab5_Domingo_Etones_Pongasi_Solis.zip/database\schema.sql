-- =====================================================================
--  OrgTrack: CHMSU Student Organization & Event Attendance Web Portal
--  ITEAPV413 - Chapter 5 Laboratory Activity
--  Group: Domingo, Etones, Pongasi, Soles
--
--  Target: MySQL 8.0+ (also tested on MariaDB 10.4, XAMPP)
--  Import:  mysql -u root -p < database/schema.sql
--
--  Design notes
--  * Third normal form: colleges -> organizations -> events, and
--    students are stored once and referenced by attendance_logs.
--  * attendance_logs is the junction between events and students.
--    UNIQUE (event_id, student_id) blocks duplicate time-ins at the
--    database level, even if two requests arrive at the same moment.
--  * RA 10173 consent is stored per log row (flag, version, timestamp)
--    and a CHECK constraint refuses any row without consent.
-- =====================================================================

DROP DATABASE IF EXISTS chmsu_orgtrack_db;
CREATE DATABASE chmsu_orgtrack_db
  CHARACTER SET utf8mb4
  COLLATE utf8mb4_unicode_ci;
USE chmsu_orgtrack_db;

-- ---------------------------------------------------------------------
-- 1. colleges: academic units of the university
-- ---------------------------------------------------------------------
CREATE TABLE colleges (
  college_id   TINYINT UNSIGNED NOT NULL AUTO_INCREMENT,
  code         VARCHAR(10)  NOT NULL,
  name         VARCHAR(120) NOT NULL,
  CONSTRAINT pk_colleges PRIMARY KEY (college_id),
  CONSTRAINT uq_colleges_code UNIQUE (code)
) ENGINE=InnoDB;

-- ---------------------------------------------------------------------
-- 2. organizations: student organizations, each under one college
--    (college_id NULL = university-wide org such as the SSC)
-- ---------------------------------------------------------------------
CREATE TABLE organizations (
  org_id       SMALLINT UNSIGNED NOT NULL AUTO_INCREMENT,
  college_id   TINYINT UNSIGNED NULL,
  acronym      VARCHAR(20)  NOT NULL,
  name         VARCHAR(150) NOT NULL,
  adviser      VARCHAR(100) NOT NULL,
  CONSTRAINT pk_organizations PRIMARY KEY (org_id),
  CONSTRAINT uq_organizations_acronym UNIQUE (acronym),
  CONSTRAINT fk_organizations_college FOREIGN KEY (college_id)
    REFERENCES colleges (college_id) ON UPDATE CASCADE ON DELETE SET NULL
) ENGINE=InnoDB;

-- ---------------------------------------------------------------------
-- 3. officers: accounts that may manage events and view records
--    Passwords are stored with password_hash() (bcrypt), never plain.
-- ---------------------------------------------------------------------
CREATE TABLE officers (
  officer_id     SMALLINT UNSIGNED NOT NULL AUTO_INCREMENT,
  org_id         SMALLINT UNSIGNED NOT NULL,
  username       VARCHAR(40)  NOT NULL,
  password_hash  VARCHAR(255) NOT NULL,
  full_name      VARCHAR(100) NOT NULL,
  role           ENUM('admin','officer') NOT NULL DEFAULT 'officer',
  last_login_at  DATETIME NULL,
  CONSTRAINT pk_officers PRIMARY KEY (officer_id),
  CONSTRAINT uq_officers_username UNIQUE (username),
  CONSTRAINT fk_officers_org FOREIGN KEY (org_id)
    REFERENCES organizations (org_id) ON UPDATE CASCADE ON DELETE RESTRICT
) ENGINE=InnoDB;

-- ---------------------------------------------------------------------
-- 4. events: activities hosted by an organization
-- ---------------------------------------------------------------------
CREATE TABLE events (
  event_id     INT UNSIGNED NOT NULL AUTO_INCREMENT,
  org_id       SMALLINT UNSIGNED NOT NULL,
  title        VARCHAR(150) NOT NULL,
  description  TEXT NULL,
  venue        VARCHAR(120) NOT NULL,
  event_date   DATE NOT NULL,
  start_time   TIME NOT NULL,
  end_time     TIME NOT NULL,
  capacity     SMALLINT UNSIGNED NOT NULL DEFAULT 100,
  created_by   SMALLINT UNSIGNED NULL,
  created_at   TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP,
  updated_at   TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  CONSTRAINT pk_events PRIMARY KEY (event_id),
  CONSTRAINT uq_events_org_title_date UNIQUE (org_id, title, event_date),
  CONSTRAINT fk_events_org FOREIGN KEY (org_id)
    REFERENCES organizations (org_id) ON UPDATE CASCADE ON DELETE RESTRICT,
  CONSTRAINT fk_events_officer FOREIGN KEY (created_by)
    REFERENCES officers (officer_id) ON UPDATE CASCADE ON DELETE SET NULL,
  CONSTRAINT ck_events_time CHECK (end_time > start_time),
  CONSTRAINT ck_events_capacity CHECK (capacity BETWEEN 1 AND 5000)
) ENGINE=InnoDB;

CREATE INDEX ix_events_date ON events (event_date);

-- ---------------------------------------------------------------------
-- 5. students: one row per student, reused across all events
-- ---------------------------------------------------------------------
CREATE TABLE students (
  student_id   INT UNSIGNED NOT NULL AUTO_INCREMENT,
  student_no   VARCHAR(12)  NOT NULL,          -- e.g. 2024-01873
  first_name   VARCHAR(60)  NOT NULL,
  last_name    VARCHAR(60)  NOT NULL,
  college_id   TINYINT UNSIGNED NOT NULL,
  course       VARCHAR(20)  NOT NULL,
  year_level   TINYINT UNSIGNED NOT NULL,
  created_at   TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP,
  CONSTRAINT pk_students PRIMARY KEY (student_id),
  CONSTRAINT uq_students_no UNIQUE (student_no),
  CONSTRAINT fk_students_college FOREIGN KEY (college_id)
    REFERENCES colleges (college_id) ON UPDATE CASCADE ON DELETE RESTRICT,
  CONSTRAINT ck_students_year CHECK (year_level BETWEEN 1 AND 5)
) ENGINE=InnoDB;

-- ---------------------------------------------------------------------
-- 6. attendance_logs: time-in / time-out of a student at an event
-- ---------------------------------------------------------------------
CREATE TABLE attendance_logs (
  log_id           INT UNSIGNED NOT NULL AUTO_INCREMENT,
  event_id         INT UNSIGNED NOT NULL,
  student_id       INT UNSIGNED NOT NULL,
  time_in          DATETIME NOT NULL,
  time_out         DATETIME NULL,
  consent_given    TINYINT(1) NOT NULL,
  consent_version  VARCHAR(10) NOT NULL,
  consent_at       DATETIME NOT NULL,
  CONSTRAINT pk_attendance_logs PRIMARY KEY (log_id),
  CONSTRAINT uq_attendance_event_student UNIQUE (event_id, student_id),
  CONSTRAINT fk_attendance_event FOREIGN KEY (event_id)
    REFERENCES events (event_id) ON UPDATE CASCADE ON DELETE CASCADE,
  CONSTRAINT fk_attendance_student FOREIGN KEY (student_id)
    REFERENCES students (student_id) ON UPDATE CASCADE ON DELETE RESTRICT,
  CONSTRAINT ck_attendance_consent CHECK (consent_given = 1),
  CONSTRAINT ck_attendance_out_after_in CHECK (time_out IS NULL OR time_out >= time_in)
) ENGINE=InnoDB;

CREATE INDEX ix_attendance_time_in ON attendance_logs (time_in);

-- =====================================================================
--  SEED DATA
--  Officer logins (for testing only, change after install):
--    admin         / OrgTrack@2026   (role: admin)
--    jpcs.officer  / Officer@2026    (role: officer)
-- =====================================================================

INSERT INTO colleges (code, name) VALUES
  ('CCS',  'College of Computer Studies'),
  ('COE',  'College of Engineering'),
  ('CBMA', 'College of Business Management and Accountancy'),
  ('CAS',  'College of Arts and Sciences');

INSERT INTO organizations (college_id, acronym, name, adviser) VALUES
  (1,    'JPCS',     'Junior Philippine Computer Society - CHMSU Chapter', 'Engr. Ramon T. Villanueva'),
  (2,    'ICpEP.SE', 'Institute of Computer Engineers of the Philippines Student Edition', 'Engr. Liza M. Gonzaga'),
  (NULL, 'SSC',      'Supreme Student Council', 'Dr. Marites P. Lacson'),
  (3,    'JMA',      'Junior Marketing Association', 'Ms. Andrea C. Yulo');

INSERT INTO officers (org_id, username, password_hash, full_name, role) VALUES
  (3, 'admin',        '$2y$10$JH02IwMxqfZhLgNhCylEr.fZR/mdRVQ6.UE8wSA858OLtths/Ra6S', 'SSC Secretariat', 'admin'),
  (1, 'jpcs.officer', '$2y$10$wYgY.dMjxW6tyrUD56KtGemKN.8q8uYcvKGLUfWaM.gIh2Tp6DZli', 'Mark Anthony Ledesma', 'officer');

INSERT INTO events (org_id, title, description, venue, event_date, start_time, end_time, capacity, created_by) VALUES
  (1, 'Tech Talk: Careers in Cloud Computing',
      'Industry speakers share entry-level paths in cloud and DevOps.',
      'CCS Audio-Visual Room', '2026-11-12', '13:00:00', '16:00:00', 60, 2),
  (3, 'General Assembly AY 2026-2027',
      'Orientation of student leaders on council programs and policies.',
      'CHMSU Gymnasium', '2026-11-17', '08:00:00', '11:30:00', 500, 1),
  (2, 'Arduino and IoT Hands-on Workshop',
      'Build a sensor node and send readings to a web dashboard.',
      'Engineering Laboratory 2', '2026-11-21', '08:00:00', '17:00:00', 40, 1),
  (4, 'Entrepreneurship Fair Orientation',
      'Booth guidelines, permits and schedule for exhibitors.',
      'CBMA Lobby', '2026-11-26', '14:00:00', '16:00:00', 80, 1),
  (1, 'Hour of Code Community Outreach',
      'Officers teach basic block programming to partner high schools.',
      'CCS Computer Laboratory 3', '2026-12-03', '09:00:00', '12:00:00', 35, 2),
  (3, 'Gift-Giving Drive Volunteers Briefing',
      'Task assignments for the December outreach program.',
      'SSC Office Conference Room', '2026-12-10', '15:00:00', '17:00:00', 30, 1);

INSERT INTO students (student_no, first_name, last_name, college_id, course, year_level) VALUES
  ('2023-01042', 'Angela Mae',   'Torres',     1, 'BSIT',  3),
  ('2023-01177', 'John Carlo',   'Bautista',   1, 'BSCS',  3),
  ('2024-00318', 'Rhea Joy',     'Montinola',  1, 'BSIS',  2),
  ('2022-00894', 'Christian',    'Dela Cruz',  2, 'BSCpE', 4),
  ('2024-00560', 'Patricia Anne','Gatuslao',   2, 'BSCpE', 2),
  ('2025-00103', 'Kenneth',      'Saldua',     2, 'BSECE', 1),
  ('2023-00741', 'Mariel',       'Javellana',  3, 'BSA',   3),
  ('2024-00925', 'Lorenzo',      'Aguirre',    3, 'BSBA',  2),
  ('2022-01390', 'Sofia Isabel', 'Ramos',      4, 'ABComm',4),
  ('2025-00266', 'Nathaniel',    'Espinosa',   1, 'BSIT',  1);

-- Past events: complete time-in / time-out pairs.
-- Today's workshop (event 3): some students are still inside (time_out NULL).
INSERT INTO attendance_logs (event_id, student_id, time_in, time_out, consent_given, consent_version, consent_at) VALUES
  (1,  1, '2026-11-12 12:51:10', '2026-11-12 16:02:44', 1, 'RA10173-1', '2026-11-12 12:51:10'),
  (1,  2, '2026-11-12 12:55:37', '2026-11-12 16:05:12', 1, 'RA10173-1', '2026-11-12 12:55:37'),
  (1,  3, '2026-11-12 13:08:02', '2026-11-12 15:40:19', 1, 'RA10173-1', '2026-11-12 13:08:02'),
  (1, 10, '2026-11-12 13:15:48', '2026-11-12 16:01:05', 1, 'RA10173-1', '2026-11-12 13:15:48'),
  (2,  1, '2026-11-17 07:42:11', '2026-11-17 11:33:50', 1, 'RA10173-1', '2026-11-17 07:42:11'),
  (2,  4, '2026-11-17 07:45:26', '2026-11-17 11:31:02', 1, 'RA10173-1', '2026-11-17 07:45:26'),
  (2,  7, '2026-11-17 07:50:03', '2026-11-17 11:35:17', 1, 'RA10173-1', '2026-11-17 07:50:03'),
  (2,  8, '2026-11-17 07:58:39', '2026-11-17 10:20:44', 1, 'RA10173-1', '2026-11-17 07:58:39'),
  (2,  9, '2026-11-17 08:03:15', '2026-11-17 11:30:28', 1, 'RA10173-1', '2026-11-17 08:03:15'),
  (3,  4, '2026-11-21 07:52:30', NULL,                  1, 'RA10173-1', '2026-11-21 07:52:30'),
  (3,  5, '2026-11-21 07:56:14', NULL,                  1, 'RA10173-1', '2026-11-21 07:56:14'),
  (3,  6, '2026-11-21 08:04:41', '2026-11-21 12:01:09', 1, 'RA10173-1', '2026-11-21 08:04:41');

<?php
/**
 * Business-logic tier: time-in / time-out rules, log retrieval and
 * dashboard statistics.
 *
 * Results are returned as ['ok' => bool, 'code' => string, 'message' => string]
 * so the same logic serves both the Fetch API and plain form posts.
 */
declare(strict_types=1);

final class AttendanceService
{
    public const COURSES = [
        'CCS'  => ['BSIT', 'BSCS', 'BSIS'],
        'COE'  => ['BSCpE', 'BSECE', 'BSCE', 'BSME'],
        'CBMA' => ['BSA', 'BSBA', 'BSHM'],
        'CAS'  => ['ABComm', 'BSPsych', 'BSBio'],
    ];

    public static function colleges(): array
    {
        return Database::run('SELECT college_id, code, name FROM colleges ORDER BY code')->fetchAll();
    }

    private static function result(bool $ok, string $code, string $message, array $extra = []): array
    {
        return ['ok' => $ok, 'code' => $code, 'message' => $message] + $extra;
    }

    /** Checks the event exists and is held today. */
    private static function openEvent(int $eventId): ?array
    {
        $ev = Database::run(
            'SELECT event_id, title, capacity, event_date = CURDATE() AS is_today
               FROM events WHERE event_id = ?',
            [$eventId]
        )->fetch();
        return ($ev && (int) $ev['is_today'] === 1) ? $ev : null;
    }

    // ------------------------------------------------------------------
    // TIME-IN
    // ------------------------------------------------------------------
    public static function timeIn(array $in): array
    {
        $eventId   = (int) ($in['event_id'] ?? 0);
        $studentNo = trim((string) ($in['student_no'] ?? ''));
        $first     = trim(preg_replace('/\s+/', ' ', (string) ($in['first_name'] ?? '')));
        $last      = trim(preg_replace('/\s+/', ' ', (string) ($in['last_name'] ?? '')));
        $collegeId = (int) ($in['college_id'] ?? 0);
        $course    = trim((string) ($in['course'] ?? ''));
        $year      = (int) ($in['year_level'] ?? 0);
        $consent   = ($in['consent'] ?? '') === 'yes';

        // RA 10173: no consent, no processing. Checked before anything is stored.
        if (!$consent) {
            return self::result(false, 'consent_required',
                'Consent is required. Under RA 10173 we cannot record your attendance without it.');
        }

        $errors = [];
        if (!preg_match('/^\d{4}-\d{5}$/', $studentNo))            $errors['student_no'] = 'Use the format 2024-01234.';
        if (!preg_match("/^[\p{L}][\p{L} .'-]{1,59}$/u", $first)) $errors['first_name'] = 'Enter your first name (letters only).';
        if (!preg_match("/^[\p{L}][\p{L} .'-]{1,59}$/u", $last))  $errors['last_name'] = 'Enter your last name (letters only).';
        $college = Database::run('SELECT code FROM colleges WHERE college_id = ?', [$collegeId])->fetchColumn();
        if (!$college)                                             $errors['college_id'] = 'Choose your college.';
        elseif (!in_array($course, self::COURSES[$college] ?? [], true)) $errors['course'] = 'Choose a course from your college.';
        if ($year < 1 || $year > 5)                                $errors['year_level'] = 'Choose your year level.';
        if ($errors) {
            return self::result(false, 'invalid', 'Please correct the highlighted fields.', ['errors' => $errors]);
        }

        $event = self::openEvent($eventId);
        if (!$event) {
            return self::result(false, 'event_closed', 'This event is not open for attendance today.');
        }

        $pdo = Database::connection();
        $pdo->beginTransaction();
        try {
            // Re-use the student record if the number already exists.
            $student = Database::run(
                'SELECT student_id, first_name, last_name FROM students WHERE student_no = ? FOR UPDATE',
                [$studentNo]
            )->fetch();

            if ($student) {
                // Guard against someone timing in with another student's number.
                if (mb_strtolower($student['last_name']) !== mb_strtolower($last)) {
                    $pdo->rollBack();
                    return self::result(false, 'mismatch', 'Student number and last name do not match our records.');
                }
                $studentId = (int) $student['student_id'];
                $displayName = $student['first_name'] . ' ' . $student['last_name'];
            } else {
                Database::run(
                    'INSERT INTO students (student_no, first_name, last_name, college_id, course, year_level)
                     VALUES (?, ?, ?, ?, ?, ?)',
                    [$studentNo, $first, $last, $collegeId, $course, $year]
                );
                $studentId = (int) $pdo->lastInsertId();
                $displayName = $first . ' ' . $last;
            }

            $count = (int) Database::run('SELECT COUNT(*) FROM attendance_logs WHERE event_id = ?', [$eventId])->fetchColumn();
            if ($count >= (int) $event['capacity']) {
                $pdo->rollBack();
                return self::result(false, 'full', 'Sorry, this event has reached its capacity.');
            }

            Database::run(
                'INSERT INTO attendance_logs (event_id, student_id, time_in, consent_given, consent_version, consent_at)
                 VALUES (?, ?, NOW(), 1, ?, NOW())',
                [$eventId, $studentId, App::config('app')['consent_version']]
            );
            $pdo->commit();
        } catch (PDOException $ex) {
            if ($pdo->inTransaction()) {
                $pdo->rollBack();
            }
            // 23000 = integrity violation: the UNIQUE (event_id, student_id) key fired.
            if ($ex->getCode() === '23000') {
                $at = Database::run(
                    'SELECT DATE_FORMAT(a.time_in, "%l:%i %p") FROM attendance_logs a
                       JOIN students s ON s.student_id = a.student_id
                      WHERE a.event_id = ? AND s.student_no = ?',
                    [$eventId, $studentNo]
                )->fetchColumn();
                return self::result(false, 'duplicate',
                    'You already timed in to this event' . ($at ? ' at ' . trim($at) : '') . '. Duplicate entries are not allowed.');
            }
            throw $ex;
        }

        return self::result(true, 'timed_in', "Welcome, {$displayName}! Time-in recorded for {$event['title']}.",
            ['time' => date('g:i A')]);
    }

    // ------------------------------------------------------------------
    // TIME-OUT
    // ------------------------------------------------------------------
    public static function timeOut(array $in): array
    {
        $eventId   = (int) ($in['event_id'] ?? 0);
        $studentNo = trim((string) ($in['student_no'] ?? ''));
        $last      = trim((string) ($in['last_name'] ?? ''));

        if (!preg_match('/^\d{4}-\d{5}$/', $studentNo) || $last === '') {
            return self::result(false, 'invalid', 'Enter your student number and last name to time out.',
                ['errors' => ['student_no' => 'Required for time-out.', 'last_name' => 'Required for time-out.']]);
        }
        if (!self::openEvent($eventId)) {
            return self::result(false, 'event_closed', 'This event is not open for attendance today.');
        }

        $log = Database::run(
            'SELECT a.log_id, a.time_out, s.first_name, s.last_name
               FROM attendance_logs a JOIN students s ON s.student_id = a.student_id
              WHERE a.event_id = ? AND s.student_no = ?',
            [$eventId, $studentNo]
        )->fetch();

        if (!$log || mb_strtolower($log['last_name']) !== mb_strtolower($last)) {
            return self::result(false, 'not_found', 'No time-in found for this student at this event.');
        }
        if ($log['time_out'] !== null) {
            return self::result(false, 'duplicate', 'You already timed out of this event.');
        }

        // "AND time_out IS NULL" makes the update safe against double clicks.
        $done = Database::run(
            'UPDATE attendance_logs SET time_out = NOW() WHERE log_id = ? AND time_out IS NULL',
            [$log['log_id']]
        )->rowCount();
        if ($done !== 1) {
            return self::result(false, 'duplicate', 'You already timed out of this event.');
        }
        return self::result(true, 'timed_out', "Goodbye, {$log['first_name']}! Time-out recorded.", ['time' => date('g:i A')]);
    }

    // ------------------------------------------------------------------
    // LOG RETRIEVAL (officers)
    // ------------------------------------------------------------------
    public static function search(int $eventId = 0, string $q = '', string $state = ''): array
    {
        $where = [];
        $params = [];
        if ($eventId > 0) {
            $where[] = 'a.event_id = ?';
            $params[] = $eventId;
        }
        if ($q !== '') {
            $where[] = "(s.student_no LIKE ? OR CONCAT(s.first_name, ' ', s.last_name) LIKE ?)";
            $params[] = '%' . $q . '%';
            $params[] = '%' . $q . '%';
        }
        if ($state === 'inside') {
            $where[] = 'a.time_out IS NULL';
        } elseif ($state === 'out') {
            $where[] = 'a.time_out IS NOT NULL';
        }

        $sql = 'SELECT a.log_id, a.time_in, a.time_out, a.consent_version,
                       TIMESTAMPDIFF(MINUTE, a.time_in, a.time_out) AS minutes,
                       s.student_no, s.first_name, s.last_name, s.course, s.year_level,
                       c.code AS college, e.title, e.event_date, o.acronym
                  FROM attendance_logs a
                  JOIN students s      ON s.student_id = a.student_id
                  JOIN colleges c      ON c.college_id = s.college_id
                  JOIN events e        ON e.event_id   = a.event_id
                  JOIN organizations o ON o.org_id     = e.org_id'
             . ($where ? ' WHERE ' . implode(' AND ', $where) : '')
             . ' ORDER BY a.time_in DESC LIMIT 300';
        return Database::run($sql, $params)->fetchAll();
    }

    public static function deleteLog(int $logId): bool
    {
        return Database::run('DELETE FROM attendance_logs WHERE log_id = ?', [$logId])->rowCount() === 1;
    }

    // ------------------------------------------------------------------
    // DASHBOARD DATA (consumed by assets/js/dashboard.js via Fetch)
    // ------------------------------------------------------------------
    public static function dashboard(): array
    {
        $totals = Database::run(
            "SELECT
               (SELECT COUNT(*) FROM events) AS events,
               (SELECT COUNT(*) FROM events WHERE event_date >= CURDATE()) AS upcoming,
               (SELECT COUNT(*) FROM students) AS students,
               (SELECT COUNT(*) FROM attendance_logs) AS logs,
               (SELECT COUNT(*) FROM attendance_logs a JOIN events e ON e.event_id = a.event_id
                 WHERE e.event_date = CURDATE() AND a.time_out IS NULL) AS inside,
               (SELECT COUNT(*) FROM attendance_logs WHERE DATE(time_in) = CURDATE()) AS today"
        )->fetch();

        $events = Database::run(
            'SELECT e.event_id, e.title, e.venue, e.event_date, e.start_time, e.end_time, e.capacity, o.acronym,
                    ' . EventRepository::STATUS_SQL . ' AS status,
                    COUNT(a.log_id) AS attendees,
                    SUM(a.log_id IS NOT NULL AND a.time_out IS NULL) AS inside
               FROM events e
               JOIN organizations o ON o.org_id = e.org_id
               LEFT JOIN attendance_logs a ON a.event_id = e.event_id
              GROUP BY e.event_id
              ORDER BY ABS(DATEDIFF(e.event_date, CURDATE())), e.event_date DESC
              LIMIT 6'
        )->fetchAll();

        $byCollege = Database::run(
            'SELECT c.code, COUNT(a.log_id) AS total
               FROM colleges c
               LEFT JOIN students s ON s.college_id = c.college_id
               LEFT JOIN attendance_logs a ON a.student_id = s.student_id
              GROUP BY c.college_id ORDER BY total DESC, c.code'
        )->fetchAll();

        $activity = Database::run(
            "SELECT * FROM (
                SELECT 'in' AS kind, a.time_in AS happened_at, s.first_name, s.last_name, s.course, e.title
                  FROM attendance_logs a JOIN students s ON s.student_id = a.student_id
                  JOIN events e ON e.event_id = a.event_id
                UNION ALL
                SELECT 'out', a.time_out, s.first_name, s.last_name, s.course, e.title
                  FROM attendance_logs a JOIN students s ON s.student_id = a.student_id
                  JOIN events e ON e.event_id = a.event_id
                 WHERE a.time_out IS NOT NULL
             ) feed ORDER BY happened_at DESC LIMIT 8"
        )->fetchAll();

        $cast = fn (array $rows, array $intKeys) => array_map(function ($r) use ($intKeys) {
            foreach ($intKeys as $k) {
                $r[$k] = (int) $r[$k];
            }
            return $r;
        }, $rows);

        return [
            'ok'           => true,
            'generated_at' => date('g:i:s A'),
            'totals'       => array_map('intval', $totals),
            'events'       => $cast($events, ['event_id', 'capacity', 'attendees', 'inside']),
            'by_college'   => $cast($byCollege, ['total']),
            'activity'     => $activity,
        ];
    }
}

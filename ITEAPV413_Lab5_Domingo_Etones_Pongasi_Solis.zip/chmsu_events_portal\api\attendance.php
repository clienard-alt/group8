<?php
/**
 * POST api/attendance.php  ->  time-in or time-out (Fetch API).
 * Body: form data with action=in|out, csrf token in X-CSRF-Token header.
 * Response: { ok, code, message, errors? }
 */
declare(strict_types=1);
require __DIR__ . '/../src/bootstrap.php';

if ($_SERVER['REQUEST_METHOD'] !== 'POST') {
    App::json(['ok' => false, 'message' => 'Method not allowed.'], 405);
}
if (!App::checkCsrf()) {
    App::json(['ok' => false, 'code' => 'csrf', 'message' => 'Security token expired. Reload the page and try again.'], 403);
}

$action = $_POST['action'] ?? '';
try {
    $result = match ($action) {
        'in'    => AttendanceService::timeIn($_POST),
        'out'   => AttendanceService::timeOut($_POST),
        default => ['ok' => false, 'code' => 'invalid', 'message' => 'Unknown action.'],
    };
} catch (Throwable $ex) {
    // Never show SQL errors to the user; log them for the officers.
    error_log('[attendance] ' . $ex->getMessage());
    App::json(['ok' => false, 'code' => 'error', 'message' => 'Something went wrong. Please try again.'], 500);
}

$status = match ($result['code']) {
    'timed_in', 'timed_out' => 200,
    'duplicate'             => 409,
    'invalid'               => 422,
    'consent_required'      => 422,
    'not_found'             => 404,
    default                 => 400,
};
App::json($result, $status);

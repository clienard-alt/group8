    <footer class="page-foot">
      <span>OrgTrack · Carlos Hilado Memorial State University</span>
      <span>Personal data is processed under RA 10173 · <a href="privacy.php">Privacy Notice</a></span>
    </footer>
  </main>
</div>
<script src="assets/vendor/bootstrap/bootstrap.bundle.min.js"></script>
<script src="assets/js/ui.js"></script>
<?php foreach ($scripts ?? [] as $s): ?>
<script src="<?= e($s) ?>"></script>
<?php endforeach; ?>
</body>
</html>

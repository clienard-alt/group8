/**
 * Shared UI: forms with a data-confirm attribute ask before submitting
 * (used for deletes). Kept in a file because the CSP blocks inline JS.
 */
document.addEventListener('submit', function (e) {
  const form = e.target;
  if (form instanceof HTMLFormElement && form.dataset.confirm && !window.confirm(form.dataset.confirm)) {
    e.preventDefault();
  }
});

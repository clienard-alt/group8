<?php
/**
 * Application configuration.
 *
 * Database values can be overridden with environment variables so the
 * same code runs on XAMPP (root, no password, port 3306) or any other
 * MySQL 8 server without editing source files.
 */
declare(strict_types=1);

return [
    'app' => [
        'name'            => 'OrgTrack',
        'full_name'       => 'CHMSU Student Organization & Event Attendance Portal',
        'timezone'        => 'Asia/Manila',
        'consent_version' => 'RA10173-1',
    ],
    'db' => [
        'host'    => getenv('DB_HOST') ?: '127.0.0.1',
        'port'    => (int) (getenv('DB_PORT') ?: 3306),
        'name'    => getenv('DB_NAME') ?: 'chmsu_orgtrack_db',
        'user'    => getenv('DB_USER') ?: 'root',
        'pass'    => getenv('DB_PASS') ?: '',
        'charset' => 'utf8mb4',
    ],
    'security' => [
        'max_login_attempts' => 5,     // per session
        'lockout_seconds'    => 60,
    ],
];

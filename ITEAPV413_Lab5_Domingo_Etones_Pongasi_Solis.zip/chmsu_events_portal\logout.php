<?php
/**
 * Logout is a POST with a CSRF token, so another site cannot log
 * an officer out with a simple link or image.
 */
declare(strict_types=1);
require __DIR__ . '/src/bootstrap.php';

if ($_SERVER['REQUEST_METHOD'] === 'POST' && App::checkCsrf()) {
    Auth::logout();
    App::flash('info', 'You have been logged out.');
}
App::redirect('login.php');
